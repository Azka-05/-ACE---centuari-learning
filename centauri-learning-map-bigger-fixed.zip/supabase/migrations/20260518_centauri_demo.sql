-- Centauri ACE demo schema. Safe to run in Supabase SQL editor.
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  name text,
  dream_career text,
  interests text[],
  xp integer default 0,
  accessibility_mode text,
  created_at timestamptz default now()
);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  node_id text not null,
  title text,
  career_id text,
  deliverable_type text,
  deliverable_url text,
  submitted_at timestamptz default now()
);

create table if not exists device_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  items jsonb,
  reason text,
  urgency text,
  location text,
  status text default 'pending',
  created_at timestamptz default now()
);

create table if not exists donations (
  id uuid primary key default gen_random_uuid(),
  donor_name text,
  donor_email text,
  item_name text,
  item_type text,
  location text,
  notes text,
  created_at timestamptz default now()
);

insert into storage.buckets (id, name, public) values ('portfolio', 'portfolio', true) on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('cvs', 'cvs', false) on conflict (id) do nothing;

alter table profiles enable row level security;
alter table projects enable row level security;
alter table device_requests enable row level security;
alter table donations enable row level security;

create policy if not exists "Profiles public read" on profiles for select using (true);
create policy if not exists "Projects public read" on projects for select using (true);
create policy if not exists "Device requests owner read" on device_requests for select using (auth.uid() = user_id);
create policy if not exists "Device requests owner insert" on device_requests for insert with check (auth.uid() = user_id);
create policy if not exists "Donations insert public" on donations for insert with check (true);
