import { useCallback, useEffect, useRef, useState } from "react";

export type SpeechState = "idle" | "playing" | "paused";

export interface UseSpeechReturn {
  supported: boolean;
  state: SpeechState;
  rate: number;
  setRate: (r: number) => void;
  charIndex: number;
  charLength: number;
  speak: (text: string) => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
}

/**
 * Browser-native Web Speech API wrapper.
 * No API key, offline-capable, mobile-friendly.
 */
export function useSpeech(initialRate = 1): UseSpeechReturn {
  const supported =
    typeof window !== "undefined" && "speechSynthesis" in window;
  const [state, setState] = useState<SpeechState>("idle");
  const [rate, setRateState] = useState(initialRate);
  const [charIndex, setCharIndex] = useState(0);
  const [charLength, setCharLength] = useState(0);
  const utterRef = useRef<SpeechSynthesisUtterance | null>(null);
  const textRef = useRef<string>("");

  const stop = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.cancel();
    setState("idle");
    setCharIndex(0);
    setCharLength(0);
  }, [supported]);

  const speak = useCallback(
    (text: string) => {
      if (!supported || !text) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = rate;
      u.pitch = 1;
      // Try to pick a calm, natural voice
      const voices = window.speechSynthesis.getVoices();
      const preferred =
        voices.find((v) => /Samantha|Google UK English Female|Karen|Serena/.test(v.name)) ||
        voices.find((v) => v.lang?.startsWith("en"));
      if (preferred) u.voice = preferred;
      u.onstart = () => setState("playing");
      u.onend = () => {
        setState("idle");
        setCharIndex(0);
      };
      u.onerror = () => setState("idle");
      u.onpause = () => setState("paused");
      u.onresume = () => setState("playing");
      u.onboundary = (e: SpeechSynthesisEvent) => {
        if (e.name === "word" || e.name === undefined) {
          setCharIndex(e.charIndex ?? 0);
          const len = (e as SpeechSynthesisEvent & { charLength?: number }).charLength;
          if (typeof len === "number") setCharLength(len);
        }
      };
      utterRef.current = u;
      textRef.current = text;
      window.speechSynthesis.speak(u);
    },
    [rate, supported],
  );

  const pause = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.pause();
    setState("paused");
  }, [supported]);

  const resume = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.resume();
    setState("playing");
  }, [supported]);

  const setRate = useCallback(
    (r: number) => {
      setRateState(r);
      // If currently playing, restart from current word for new rate
      if (state !== "idle" && textRef.current) {
        const remaining = textRef.current.slice(charIndex);
        window.speechSynthesis.cancel();
        setTimeout(() => speak(remaining), 50);
      }
    },
    [charIndex, speak, state],
  );

  useEffect(() => () => stop(), [stop]);

  // Ensure voices list is loaded
  useEffect(() => {
    if (!supported) return;
    const handler = () => void window.speechSynthesis.getVoices();
    window.speechSynthesis.onvoiceschanged = handler;
    handler();
    return () => {
      if (window.speechSynthesis) window.speechSynthesis.onvoiceschanged = null;
    };
  }, [supported]);

  return { supported, state, rate, setRate, charIndex, charLength, speak, pause, resume, stop };
}
