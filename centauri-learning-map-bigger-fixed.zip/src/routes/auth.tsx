import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Compass, Loader2, Mail, Lock, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/auth")({
  component: AuthPage,
  head: () => ({
    meta: [
      { title: "Sign in or sign up — Centauri Learning" },
      { name: "description", content: "Create your Centauri Learning account or log back in to continue your pathway." },
    ],
  }),
});

function AuthPage() {
  const nav = useNavigate();
  const { session, authReady, hasOnboarded } = useApp();
  const [mode, setMode] = useState<"login" | "signup">("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // Redirect when authenticated
  useEffect(() => {
    if (authReady && session) {
      nav({ to: hasOnboarded ? "/" : "/onboarding" });
    }
  }, [authReady, session, hasOnboarded, nav]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return setError("Please enter a valid email.");
    if (password.length < 8) return setError("Password must be at least 8 characters.");
    if (mode === "signup" && !name.trim()) return setError("Please share your name.");
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { emailRedirectTo: window.location.origin, data: { name } },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4 py-12">
      <Link to="/" className="absolute left-6 top-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <Compass className="h-4 w-4 text-accent" /> Centauri Learning
      </Link>
      <div
        className="w-full max-w-md rounded-3xl border border-border bg-card/60 p-8 shadow-elegant backdrop-blur"
      >
        <div className="mb-6 flex rounded-xl border border-border bg-muted/40 p-1 text-sm">
          {(["signup", "login"] as const).map((m) => (
            <button key={m} onClick={() => { setMode(m); setError(""); }}
              className={`flex-1 rounded-lg py-2 font-medium transition-all ${
                mode === m ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}>
              {m === "signup" ? "Create account" : "Log in"}
            </button>
          ))}
        </div>

        <h1 className="text-2xl font-bold">
          {mode === "signup" ? "Welcome — let's start your pathway." : "Welcome back."}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {mode === "signup"
            ? "No pressure. Just a few details to get you set up."
            : "Sign in to pick up where you left off."}
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "signup" && (
            <Field icon={<User className="h-4 w-4" />} label="Your name">
              <input value={name} onChange={(e) => setName(e.target.value)} className="auth-input" placeholder="Alex Johnson" autoComplete="name" />
            </Field>
          )}
          <Field icon={<Mail className="h-4 w-4" />} label="Email">
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="auth-input" placeholder="you@example.com" autoComplete="email" />
          </Field>
          <Field icon={<Lock className="h-4 w-4" />} label="Password" hint={mode === "signup" ? "At least 8 characters." : undefined}>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="auth-input" placeholder="••••••••"
              autoComplete={mode === "signup" ? "new-password" : "current-password"} />
          </Field>

          {error && <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}

          <button type="submit" disabled={loading}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 disabled:opacity-60">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {mode === "signup" ? "Create my account" : "Log in"}
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          {mode === "signup" ? "Already have an account?" : "New to Centauri Learning?"}{" "}
          <button onClick={() => { setMode(mode === "signup" ? "login" : "signup"); setError(""); }}
            className="font-medium text-accent hover:underline">
            {mode === "signup" ? "Log in" : "Create one"}
          </button>
        </p>
      </div>
    </div>
  );
}

function Field({ icon, label, hint, children }: { icon: React.ReactNode; label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      <div className="relative">
        <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</span>
        {children}
      </div>
      {hint && <span className="mt-1 block text-xs text-muted-foreground">{hint}</span>}
    </label>
  );
}
