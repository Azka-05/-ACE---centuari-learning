import { createFileRoute } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useMemo, useState } from "react";
import { Lock, Check, X, Flame, Trophy, ArrowRight, Sparkles, Star, Link as LinkIcon } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { RequireAuth } from "@/components/RequireAuth";
import { StarMascot } from "@/components/StarMascot";
import { StarProgress } from "@/components/StarProgress";
import { ListenButton } from "@/components/ListenButton";
import { useApp } from "@/lib/app-state";
import { todayISO } from "@/lib/gamification";
import { getCareer, type CareerNode, type CareerTree } from "@/lib/careers";

export const Route = createFileRoute("/explore")({
  component: () => <RequireAuth requireOnboarding><ExplorePage /></RequireAuth>,
  head: () => ({
    meta: [
      { title: "Explore — Centauri Learning" },
      { name: "description", content: "Your personalised, evolving career pathway. Two trees, one future." },
    ],
  }),
});

function ExplorePage() {
  const { user, updateUser, awardXp } = useApp();
  const dreamCareer = useMemo(() => getCareer(user.dreamCareer), [user.dreamCareer]);
  const selectedTrees = useMemo(() => treesFromInterests(user.interests, user.dreamCareer), [user.interests, user.dreamCareer]);
  const career = dreamCareer;
  const completed = new Set(user.completedLessons);
  const [openNode, setOpenNode] = useState<CareerNode | null>(null);

  const completeNode = (n: { id: string; xp: number }) => {
    if (completed.has(n.id)) { setOpenNode(null); return; }
    const d = todayISO();
    const isNewDay = user.lastActive !== d;
    const source = `${n.id}:complete`;
    awardXp(source, n.xp, n.id);
    updateUser({
      completedLessons: [...user.completedLessons, n.id],
      streak: isNewDay ? (user.streak || 0) + 1 : user.streak || 1,
      lastActive: d,
    });
    setOpenNode(null);
  };

  // Compute first available node per tree
  const stateFor = (tree: CareerTree) => {
    const firstLocked = tree.nodes.findIndex((n) => !completed.has(n.id));
    return tree.nodes.map((n, i) => ({
      node: n,
      done: completed.has(n.id),
      current: i === firstLocked,
      locked: firstLocked !== -1 && i > firstLocked,
    }));
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-hero pb-24">
      <ConstellationBackdrop />
      <Navbar />

      <div className="relative mx-auto mt-8 max-w-6xl px-4">
        {/* HEADER */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
          className="glass rounded-3xl p-6 shadow-elegant md:p-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">Your pathway</div>
              <h1 className="mt-1 text-3xl font-bold md:text-4xl">{career.emoji} {career.name}</h1>
              <p className="mt-1 max-w-lg text-sm text-muted-foreground">Your pathway: {career.name} · Building toward this through {(user.interests || []).slice(0,2).join(" + ") || "your chosen missions"}</p>
            </div>
            <div className="flex items-center gap-4">
              <StarProgress size={92} compact />
              <Stat label="Streak" value={<span className="inline-flex items-center gap-1"><Flame className="h-4 w-4 text-accent" />{user.streak || 0}d</span>} />
            </div>
          </div>
          <p className="mt-3 text-xs italic text-muted-foreground">Small steps become careers. Every node you light up is real growth.</p>
        </motion.div>

        {/* DUAL TREES */}
        <section className="mt-10 grid gap-8 md:grid-cols-2">
          {selectedTrees.map((tree, idx) => (
            <NodeTree key={tree.id} tree={tree} states={stateFor(tree)} side={idx === 0 ? "left" : "right"}
              onPick={(n) => setOpenNode(n)} />
          ))}
        </section>

        {/* LEADERBOARD */}
        <BottomSection userName={user.name} userXp={user.xp} careerName={career.name} />
      </div>

      <AnimatePresence>
        {openNode && (
          <LessonModal node={openNode} done={completed.has(openNode.id)}
            onClose={() => setOpenNode(null)} onComplete={() => completeNode(openNode)} />
        )}
      </AnimatePresence>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="text-right">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-sm font-bold">{value}</div>
    </div>
  );
}

// =================== NODE TREE ===================
interface NodeState { node: CareerNode; done: boolean; current: boolean; locked: boolean }

function NodeTree({ tree, states, side, onPick }: {
  tree: CareerTree; states: NodeState[]; side: "left" | "right";
  onPick: (n: CareerNode) => void;
}) {
  // Layout: each node at fixed Y, X zig-zags
  // Bigger, bolder layout so the map fills the card and reads well in demos.
  const W = 520;
  const NODE_GAP = 145;
  const H = NODE_GAP * Math.max(0, states.length - 1) + 150;
  const positions = states.map((_, i) => {
    const offset = i % 2 === 0 ? -105 : 105;
    const cx = W / 2 + offset;
    const cy = 75 + i * NODE_GAP;
    return { cx, cy };
  });

  const treeProgress = states.filter((s) => s.done).length / Math.max(1, states.length);

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
      className="glass relative min-h-[640px] overflow-hidden rounded-3xl p-6 shadow-elegant md:p-8">
      {/* Tree header */}
      <div className="mb-2 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold md:text-2xl" style={{
            background: `linear-gradient(90deg, ${tree.hueA}, ${tree.hueB})`,
            WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
          }}>{tree.title}</h2>
          <p className="text-sm font-medium text-muted-foreground">{tree.subtitle}</p>
        </div>
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{Math.round(treeProgress * 100)}%</div>
      </div>

      {/* SVG tree */}
      <div className="relative mx-auto w-full" style={{ maxWidth: W, aspectRatio: `${W} / ${H}` }}>
        <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" className="absolute inset-0 h-full w-full">

          <defs>
            <linearGradient id={`grad-${tree.id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={tree.hueA} stopOpacity="0.9" />
              <stop offset="100%" stopColor={tree.hueB} stopOpacity="0.9" />
            </linearGradient>
            <filter id={`glow-${tree.id}`} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="4" result="b" />
              <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>

          {/* connecting branches */}
          {positions.slice(1).map((p, i) => {
            const prev = positions[i];
            const s = states[i];
            const next = states[i + 1];
            const lit = s.done; // line is lit if previous done
            const mx = (prev.cx + p.cx) / 2;
            const d = `M ${prev.cx} ${prev.cy} C ${prev.cx} ${(prev.cy + p.cy) / 2}, ${p.cx} ${(prev.cy + p.cy) / 2}, ${p.cx} ${p.cy}`;
            void mx; void next;
            return (
              <motion.path key={i} d={d} fill="none"
                stroke={lit ? `url(#grad-${tree.id})` : "color-mix(in oklch, var(--muted-foreground) 30%, transparent)"}
                strokeWidth={lit ? 4 : 2.25}
                strokeDasharray={lit ? "0" : "4 4"}
                filter={undefined}
                initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1, delay: i * 0.1 }}
              />
            );
          })}

          {/* nodes */}
          {positions.map((p, i) => {
            const s = states[i];
            const r = s.current ? 30 : 25;
            return (
              <g key={s.node.id}
                style={{ cursor: s.locked ? "not-allowed" : "pointer" }}
                onClick={() => !s.locked && onPick(s.node)}>
                {/* outer glow */}
                {!s.locked && (
                  <motion.circle cx={p.cx} cy={p.cy} r={r + 18}
                    fill={`url(#grad-${tree.id})`} opacity={s.current ? 0.35 : s.done ? 0.25 : 0.15}
                    filter={`url(#glow-${tree.id})`}
                    animate={s.current ? { r: [r + 16, r + 26, r + 16], opacity: [0.25, 0.42, 0.25] } : {}}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }} />
                )}
                {/* core */}
                <circle cx={p.cx} cy={p.cy} r={r}
                  fill={s.locked
                    ? "color-mix(in oklch, var(--muted) 80%, transparent)"
                    : `url(#grad-${tree.id})`}
                  stroke={s.current ? tree.hueA : "color-mix(in oklch, var(--border) 80%, transparent)"}
                  strokeWidth={s.current ? 2 : 1}
                  opacity={s.locked ? 0.5 : 1}
                />
                {/* icon */}
                <foreignObject x={p.cx - 16} y={p.cy - 16} width="32" height="32">
                  <div className="flex h-8 w-8 items-center justify-center text-white">
                    {s.locked ? <Lock className="h-5 w-5" /> : s.done ? <Check className="h-5 w-5" /> : <Star className="h-5 w-5" />}
                  </div>
                </foreignObject>
              </g>
            );
          })}

          {/* labels */}
          {positions.map((p, i) => {
            const s = states[i];
            const labelX = p.cx > W / 2 ? p.cx - 52 : p.cx + 52;
            const anchor = p.cx > W / 2 ? "end" : "start";
            return (
              <text key={"l" + s.node.id} x={labelX} y={p.cy + 6} textAnchor={anchor}
                style={{ fontSize: 17, fontWeight: 800 }}
                fill={s.locked ? "color-mix(in oklch, var(--muted-foreground) 70%, transparent)" : "var(--foreground)"}>
                {s.node.title}
              </text>
            );
          })}
        </svg>
      </div>

      <div className="mt-4 flex items-center gap-2 text-sm font-semibold text-muted-foreground">
        <Sparkles className="h-3 w-3" style={{ color: tree.hueA }} />
        <span>Complete each node and pass the quiz to unlock the next.</span>
      </div>
    </motion.div>
  );
}

// =================== BOTTOM SECTION ===================
function BottomSection({ userName, userXp }: { userName: string; userXp: number; careerName: string }) {
  const base = [
    { name: "Maya", xp: 1240 }, { name: "Jay", xp: 1110 }, { name: "Sade", xp: 980 },
    { name: "Kai", xp: 820 }, { name: "Tomi", xp: 640 },
  ];
  const all = [...base, { name: userName?.split(" ")[0] || "You", xp: userXp }].sort((a, b) => b.xp - a.xp);
  const medals = ["🥇", "🥈", "🥉"];

  return (
    <section className="mt-14 flex justify-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="glass relative w-full max-w-2xl overflow-hidden rounded-3xl p-8 text-center shadow-elegant"
        style={{ boxShadow: "0 0 80px -10px color-mix(in oklch, var(--accent) 70%, transparent)" }}
      >
        <motion.div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-accent/30 blur-3xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.85, 0.5] }} transition={{ duration: 6, repeat: Infinity }} />
        <motion.div className="absolute -bottom-24 -left-16 h-60 w-60 rounded-full bg-primary/25 blur-3xl"
          animate={{ scale: [1.1, 1, 1.1], opacity: [0.4, 0.7, 0.4] }} transition={{ duration: 7, repeat: Infinity }} />
        <div className="relative">
          <div className="inline-flex items-center justify-center gap-2 rounded-full bg-accent/15 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.25em] text-accent">
            <Trophy className="h-4 w-4" /> Leaderboard · This week
          </div>
          <h2 className="mt-4 text-3xl font-bold md:text-4xl">
            <span className="text-gradient">Top learners</span>
          </h2>
          <ol className="mx-auto mt-6 max-w-md space-y-2.5">
            {all.map((p, i) => {
              const isYou = p.name === (userName?.split(" ")[0] || "You");
              return (
                <motion.li
                  key={p.name + i}
                  initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`flex items-center justify-between rounded-2xl px-5 py-3 text-base ${
                    isYou
                      ? "bg-gradient-to-r from-primary/25 to-accent/25 ring-2 ring-primary/60 glow-primary"
                      : i < 3 ? "bg-muted/60" : "bg-muted/30"
                  }`}>
                  <div className="flex items-center gap-3">
                    <span className="w-8 text-center text-lg font-bold">
                      {medals[i] ?? <span className="text-muted-foreground">{i + 1}</span>}
                    </span>
                    <span className={`font-bold ${isYou ? "text-primary" : ""}`}>{p.name}{isYou && " (you)"}</span>
                  </div>
                  <span className="text-sm font-bold">{p.xp.toLocaleString()} XP</span>
                </motion.li>
              );
            })}
          </ol>
          <p className="mt-5 text-sm italic text-muted-foreground">Everyone grows at their own pace — keep showing up.</p>
        </div>
      </motion.div>
    </section>
  );
}

// =================== LESSON MODAL (lesson → exercise → quiz → win) ===================
function LessonModal({ node, done, onClose, onComplete }: {
  node: CareerNode; done: boolean; onClose: () => void; onComplete: () => void;
}) {
  const [step, setStep] = useState<"intro" | "exercise" | "quiz" | "win">("intro");
  const [quizIdx, setQuizIdx] = useState(0);
  const [choice, setChoice] = useState<number | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [deliverableUrl, setDeliverableUrl] = useState("");
  const { user, updateUser } = useApp();
  const completeAndSave = () => {
    if (node.kind === "project") {
      const url = deliverableUrl || "Demo submission link";
      const exists = (user.projects || []).some((p) => p.nodeId === node.id);
      if (!exists) updateUser({ projects: [...(user.projects || []), { id: crypto.randomUUID?.() || `${Date.now()}`, nodeId: node.id, title: node.title, deliverableType: node.deliverable?.type || "url", deliverableUrl: url, submittedAt: new Date().toISOString() }] });
    }
    onComplete();
  };

  const totalQ = node.quiz.length;
  const current = node.quiz[quizIdx];
  const requiredCorrect = totalQ; // all questions correct for demo rigour

  const submit = () => {
    if (choice === null) return;
    setShowFeedback(true);
    if (choice === current.correct) setCorrectCount((c) => c + 1);
  };

  const nextQ = () => {
    if (quizIdx + 1 < totalQ) {
      setQuizIdx(quizIdx + 1);
      setChoice(null);
      setShowFeedback(false);
    } else {
      // Quiz done — check pass
      if (correctCount + (choice === current.correct ? 1 : 0) >= requiredCorrect) {
        setStep("win");
      } else {
        // retry without closing
        setStep("quiz");
        setQuizIdx(0);
        setChoice(null);
        setCorrectCount(0);
        setShowFeedback(false);
      }
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-md md:items-center"
      onClick={onClose}>
      <motion.div
        initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        transition={{ type: "spring", damping: 28, stiffness: 280 }}
        onClick={(e) => e.stopPropagation()}
        className="surface w-full max-w-2xl rounded-t-3xl bg-card p-6 shadow-elegant md:rounded-3xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-accent">{node.kind} · +{node.xp} XP</div>
            <h2 className="mt-1 text-2xl font-bold leading-tight">{node.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{node.blurb}</p>
            <div className="mt-3">
              <ListenButton
                text={`${node.title}. ${node.blurb}. ${node.content.join(" ")} Try it: ${node.exercise}`}
                label="Listen instead"
              />
            </div>
          </div>
          <button onClick={onClose} aria-label="Close" className="rounded-xl p-1.5 hover:bg-muted"><X className="h-5 w-5" /></button>
        </div>

        {/* progress */}
        <div className="mt-4 flex gap-1.5">
          {["intro", "exercise", "quiz"].map((s) => {
            const order = ["intro", "exercise", "quiz", "win"];
            const idx = order.indexOf(step);
            const sIdx = order.indexOf(s);
            return (
              <div key={s} className={`h-1 flex-1 rounded-full ${sIdx <= idx ? "bg-primary" : "bg-muted"}`} />
            );
          })}
        </div>

        <div className="mt-5 max-h-[55vh] overflow-y-auto pr-1">
          {step === "intro" && (
            <div className="space-y-3">
              {node.content.map((p, i) => (
                <p key={i} className="text-sm leading-relaxed text-foreground/85">{p}</p>
              ))}
            </div>
          )}

          {step === "exercise" && (
            <div className="rounded-2xl bg-accent/10 p-4">
              <div className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">{node.kind === "project" ? "Ship something" : "Try it"}</div>
              <p className="mt-2 text-sm leading-relaxed">{node.exercise}</p>
              <p className="mt-3 text-xs text-muted-foreground">Take your time. When you're done, tap continue to check what you learned.</p>
              {node.kind === "project" && node.deliverable && (
                <div className="mt-4 rounded-2xl border border-border bg-background/45 p-4">
                  <div className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Deliverable</div>
                  <p className="text-sm font-medium">{node.deliverable.prompt}</p>
                  <div className="mt-2 flex flex-wrap gap-1">{node.deliverable.examples.map((e) => <span key={e} className="rounded-full bg-muted px-2 py-1 text-[11px] text-muted-foreground">{e}</span>)}</div>
                  <div className="mt-3 flex items-center gap-2 rounded-xl border border-border bg-muted/30 px-3 py-2">
                    <LinkIcon className="h-4 w-4 text-accent" />
                    <input value={deliverableUrl} onChange={(e)=>setDeliverableUrl(e.target.value)} placeholder="Paste your project link or file URL" className="w-full bg-transparent text-sm outline-none" />
                  </div>
                </div>
              )}
            </div>
          )}

          {step === "quiz" && (
            <div className="space-y-3">
              <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Question {quizIdx + 1} of {totalQ}</div>
              <div className="font-medium leading-snug">{current.q}</div>
              <div className="space-y-2">
                {current.options.map((opt, i) => {
                  const picked = choice === i;
                  const right = showFeedback && i === current.correct;
                  const wrong = showFeedback && picked && i !== current.correct;
                  return (
                    <button key={i}
                      onClick={() => !showFeedback && setChoice(i)}
                      disabled={showFeedback}
                      className={`w-full rounded-2xl border p-3 text-left text-sm transition-all ${
                        right ? "border-emerald-500/60 bg-emerald-500/10"
                          : wrong ? "border-destructive/50 bg-destructive/10"
                            : picked ? "border-primary bg-primary/10"
                              : "border-border bg-muted/30 hover:border-primary/50"
                      }`}>
                      {opt}
                    </button>
                  );
                })}
              </div>
              {showFeedback && (
                <div className={`rounded-2xl p-3 text-sm ${choice === current.correct ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : "bg-accent/10 text-foreground"}`}>
                  <strong>{choice === current.correct ? "Nice one." : "Almost there — review and try again next time."}</strong>{" "}
                  {current.why}
                </div>
              )}
            </div>
          )}

          {step === "win" && (
            <div className="text-center">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", damping: 12 }}
                className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[var(--peaches)] to-[var(--rosewood)] text-white glow-primary">
                <Star className="h-10 w-10" />
              </motion.div>
              <div className="mt-3 text-xl font-bold">+{node.xp} XP unlocked</div>
              <p className="mt-1 text-sm text-muted-foreground">
                {done ? "Already complete — welcome back." : "You unlocked a new pathway. One step closer."}
              </p>
              <div className="mt-3"><StarMascot message="You're building real skills." size={44} /></div>
            </div>
          )}
        </div>

        {/* footer actions */}
        <div className="mt-5 flex items-center justify-between gap-3">
          {step === "quiz" ? (
            <>
              <div className="text-sm font-medium text-muted-foreground">Need {requiredCorrect} of {totalQ} correct to unlock.</div>
              {!showFeedback ? (
                <button onClick={submit} disabled={choice === null}
                  className="inline-flex items-center gap-1.5 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground glow-primary disabled:opacity-40">
                  Check answer
                </button>
              ) : (
                <button onClick={nextQ}
                  className="inline-flex items-center gap-1.5 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground glow-primary">
                  {quizIdx + 1 < totalQ ? "Next question" : "Finish quiz"} <ArrowRight className="h-4 w-4" />
                </button>
              )}
            </>
          ) : step === "win" ? (
            <button onClick={completeAndSave}
              className="ml-auto inline-flex items-center gap-1.5 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground glow-primary">
              Collect reward
            </button>
          ) : (
            <button onClick={() => { if (step === "intro") setStep("exercise"); else if (node.kind === "project") setStep("win"); else setStep("quiz"); }}
              className="ml-auto inline-flex items-center gap-1.5 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground glow-primary">
              {step === "intro" ? "Try the exercise" : node.kind === "project" ? "Submit project" : "Take the quiz"} <ArrowRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}


function treesFromInterests(interests: string[] = [], dreamCareer?: string): [CareerTree, CareerTree] {
  const map: Record<string, string> = {
    "coding": "software-dev", "web development": "software-dev", "game development": "software-dev",
    "ux/ui design": "ux-designer", "design": "ux-designer",
    "ai": "ai-engineer", "data": "data-engineer", "hardware / repair": "data-engineer",
    "video editing": "video-editor", "digital marketing": "digital-marketer", "cybersecurity": "cyber-analyst",
    "content creation": "content-creator", "not sure yet": dreamCareer || "software-dev",
  };
  const picked = interests.map(i => map[i.toLowerCase()] || map[i] || "").filter(Boolean);
  const unique = Array.from(new Set(picked));
  const first = getCareer(unique[0] || dreamCareer).trees[0];
  const secondCareer = getCareer(unique[1] || dreamCareer || unique[0]);
  const second = secondCareer.trees[0].id === first.id ? secondCareer.trees[1] : secondCareer.trees[0];
  return [ensureMinimumNodes(first), ensureMinimumNodes(second)];
}

function ensureMinimumNodes(tree: CareerTree): CareerTree {
  if (tree.nodes.length >= 4) return tree;
  const needed = 4 - tree.nodes.length;
  const additions: CareerNode[] = Array.from({ length: needed }, (_, index) => ({
    id: `${tree.id}-extra-${index + 1}`,
    title: index === 0 ? "Portfolio Proof" : `Practice Step ${index + 1}`,
    xp: index === 0 ? 80 : 40,
    kind: index === 0 ? "project" : "challenge",
    blurb: index === 0 ? "Turn what you learned into something you can show." : "A short practice step to keep your pathway moving.",
    content: [
      "This extra step keeps the learning journey feeling complete. It gives you another small, achievable milestone before the pathway ends.",
      "The goal is to build evidence of progress, not just read information. A simple screenshot, link, or short reflection is enough for a beginner stage.",
      "Common beginner mistake: waiting until everything looks perfect. In tech, shipping a small version teaches you faster than planning forever."
    ],
    exercise: index === 0 ? "Create a tiny portfolio proof: a screenshot, link, or short note showing what you made from this pathway." : "Write down one thing you understood and one thing you want to practise next.",
    deliverable: index === 0 ? { type: "url", prompt: "Share a link, screenshot folder, or short write-up that proves what you built.", examples: ["Figma share link", "GitHub/CodePen link", "Google Drive folder"] } : undefined,
    quiz: [
      { q: "What matters most at beginner stage?", options: ["Looking perfect", "Showing steady progress", "Avoiding feedback"], correct: 1, why: "Progress and evidence matter more than perfection." },
      { q: "Why add portfolio proof?", options: ["To show real growth", "To replace learning", "To make the page longer"], correct: 0, why: "Proof helps mentors and employers see what you can do." },
      { q: "What should you do after completing a task?", options: ["Hide it", "Reflect and improve", "Start over every time"], correct: 1, why: "Reflection turns a task into learning." }
    ],
    keyTakeaways: ["Small proof builds confidence", "Progress beats perfection", "Reflection makes learning stick"]
  }));
  return { ...tree, nodes: [...tree.nodes, ...additions] };
}

// =================== BACKDROP ===================
function ConstellationBackdrop() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-0 overflow-hidden a11y-hide-adhd">
      {[...Array(28)].map((_, i) => {
        const size = 1.5 + ((i * 13) % 4);
        return (
          <motion.span key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: size, height: size,
              left: `${(i * 37) % 100}%`, top: `${(i * 53) % 100}%`,
              filter: "blur(0.6px)",
              boxShadow: "0 0 6px 1px color-mix(in oklch, var(--accent) 50%, transparent)",
            }}
            animate={{ opacity: [0.2, 0.85, 0.2] }}
            transition={{ duration: 4 + (i % 5), repeat: Infinity, ease: "easeInOut", delay: i * 0.2 }}
          />
        );
      })}
    </div>
  );
}
