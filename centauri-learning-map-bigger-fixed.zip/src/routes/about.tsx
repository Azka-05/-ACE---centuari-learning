import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Shield, Users, Compass, Sparkles } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { StarMascot } from "@/components/StarMascot";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/about")({
  component: About,
  head: () => ({
    meta: [
      { title: "About ACE — Centauri Learning" },
      { name: "description", content: "ACE = Access, Connect, Explore. A calm pathway into technology for young people." },
      { property: "og:title", content: "About ACE — Centauri Learning" },
      { property: "og:description", content: "Access opportunity. Connect with people. Explore your future." },
    ],
  }),
});

const PILLARS = [
  {
    letter: "A",
    title: "Access",
    icon: Shield,
    body: "Devices, internet, and opportunities — matched to where you are right now. No laptop? No network? No problem.",
    points: ["Devices & affordable kit", "Free learning resources", "Real-world opportunities"],
  },
  {
    letter: "C",
    title: "Connect",
    icon: Users,
    body: "Mentors who share your story. A community that wants you to win. Warm intros, not cold applications.",
    points: ["Matched mentors", "Peer community", "Industry professionals"],
  },
  {
    letter: "E",
    title: "Explore",
    icon: Compass,
    body: "A calm pathway through coding, design, cyber, AI and creative tech. Small steps, every day.",
    points: ["Skill pathways", "Daily tasks", "Your future, on your terms"],
  },
];

function About() {
  const { session, hasOnboarded } = useApp();
  const ctaTo = session ? (hasOnboarded ? "/explore" : "/onboarding") : "/auth";

  return (
    <div className="min-h-screen bg-hero pb-24">
      <Navbar />

      <section className="mx-auto max-w-4xl px-4 pt-12 text-center md:pt-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
          <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-accent" /> Centauri ACE
          </span>
          <h1 className="mt-6 text-5xl font-bold leading-tight md:text-7xl">
            <span className="text-gradient">ACE</span> Your Learning
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg">
            Access opportunity. Connect with people. Explore your future. <br />
            Built for potential, not privilege.
          </p>
          <div className="mt-8 flex justify-center">
            <StarMascot message="Your pathway into technology starts here." />
          </div>
        </motion.div>
      </section>

      <section className="mx-auto mt-16 grid max-w-6xl gap-6 px-4 md:grid-cols-3">
        {PILLARS.map((p, i) => (
          <motion.div
            key={p.letter}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.12 }}
            whileHover={{ y: -6 }}
            className="glass group relative overflow-hidden rounded-3xl p-7 shadow-elegant"
          >
            <motion.div
              className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-accent/10 blur-3xl"
              animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.7, 0.4] }}
              transition={{ duration: 5, repeat: Infinity, delay: i * 0.5 }}
            />
            <div className="relative">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/30 to-accent/30 font-display text-3xl font-bold text-primary">
                  {p.letter}
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">Pillar {i + 1}</div>
                  <h3 className="text-2xl font-semibold">{p.title}</h3>
                </div>
              </div>
              <p className="mt-4 text-sm text-muted-foreground">{p.body}</p>
              <ul className="mt-4 space-y-1.5 text-sm">
                {p.points.map((pt) => (
                  <li key={pt} className="flex items-center gap-2">
                    <p.icon className="h-3.5 w-3.5 text-accent" /> {pt}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </section>

      <section className="mx-auto mt-20 max-w-3xl px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="glass rounded-3xl p-8 text-center shadow-elegant md:p-12"
        >
          <h2 className="text-2xl font-bold md:text-3xl">No laptop? No network? No problem.</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Centauri Learning helps you access tools, build confidence, and discover real pathways into tech —
            even if you're starting with nothing but curiosity.
          </p>
        </motion.div>
      </section>

      <section className="mx-auto mt-20 max-w-3xl px-4 text-center">
        <Link
          to={ctaTo}
          className="group inline-flex items-center gap-2 rounded-2xl bg-primary px-8 py-4 text-lg font-semibold text-primary-foreground shadow-elegant glow-primary transition-all hover:scale-105"
        >
          Start Your Journey
          <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
        </Link>
        <p className="mt-4 text-xs text-muted-foreground">Free, always. Built for everyone.</p>
      </section>
    </div>
  );
}
