import { createFileRoute } from "@tanstack/react-router";
import { motion, AnimatePresence, PanInfo } from "framer-motion";
import { useMemo, useState } from "react";
import { ShoppingBasket, X, Heart, ExternalLink, Filter, Check, Sparkles } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { RequireAuth } from "@/components/RequireAuth";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/access")({
  component: () => <RequireAuth requireOnboarding><AccessPage /></RequireAuth>,
  head: () => ({ meta: [{ title: "Tech Hub Access — Centauri Learning" }, { name: "description", content: "Find donated, refurbished, and affordable tech matched to your needs." }] }),
});

const ELIGIBILITY = [
  "I don't have my own laptop",
  "I share a device with family",
  "My internet is unreliable",
  "I need a better device for my learning goals",
  "I cannot afford equipment right now",
  "I need accessible equipment",
  "Other",
];

type DeviceType = "Donated" | "Refurbished" | "Affordable";
interface Item { id: string; name: string; type: DeviceType; score: number; bestFor: string[]; desc: string; location: string; available: boolean; price: number; link: string; image: string; category: string; }

const BASKET_ITEM_LINK = "https://www.amazon.co.uk/HP-EliteBook-830-G5-i5-8250U/dp/B0DJWLWVFX/ref=sr_1_4?dib=eyJ2IjoiMSJ9.jfe9AdxTqYmfEaL3ZlQ4VVKaWFtkobTszCLmiqNzZUY6G7tKOOMk-LQr7uI_3hfxOZn4-oAei-cIvMMzOiUIURITAHdzG3HYXWEbcEOcrr8qM15dPbdWyv_E35vZPweOkma8y077eYVEuLGYZtlxhAjgX_RjDgjadYbf5JPk8-7f-lCFg9Tj5PbmFkaEBgyo3f7MNfrwLvvC3upIk9Xnqdg0Mi_eMf6QIZyzE3prZ4Y.Lx2_6wKRvuhjJ8VTo853KgXnpng4Wm6csN1XtIDLlvw&dib_tag=se&keywords=refurbished+laptops&qid=1779187513&sr=8-4";

const ITEMS: Item[] = [
  { id: "1", name: "ThinkPad T480 (Refurb)", type: "Refurbished", score: 92, bestFor: ["coding", "schoolwork"], desc: "Reliable workhorse, great Linux support. 8GB RAM, 256GB SSD.", location: "London · Free delivery", available: true, price: 0, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=800&q=80", category: "Laptop" },
  { id: "2", name: "iPad Air 2 (Donated)", type: "Donated", score: 78, bestFor: ["design", "video editing"], desc: "Donated by a local studio. Comes with Apple Pencil.", location: "Manchester · Pickup", available: true, price: 0, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=800&q=80", category: "Tablet" },
  { id: "3", name: "MacBook Air 2017 (Refurb)", type: "Refurbished", score: 88, bestFor: ["design", "coding"], desc: "Lightweight, perfect for travel and uni.", location: "Birmingham · Free delivery", available: true, price: 199, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80", category: "Laptop" },
  { id: "4", name: "4G WiFi Dongle + Data Plan", type: "Donated", score: 95, bestFor: ["schoolwork", "everything"], desc: "6 months free data — covers home learning.", location: "UK wide · Post", available: true, price: 0, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1606904825846-647eb07f5be2?auto=format&fit=crop&w=800&q=80", category: "Internet" },
  { id: "5", name: "Pixel 4a (Refurb)", type: "Refurbished", score: 75, bestFor: ["digital marketing", "video editing"], desc: "Great camera, perfect for content creation.", location: "Leeds · Free delivery", available: true, price: 89, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80", category: "Phone" },
  { id: "6", name: "Mechanical Keyboard (Donated)", type: "Donated", score: 68, bestFor: ["coding"], desc: "Tactile switches, USB-C. Great for long sessions.", location: "Bristol · Pickup", available: true, price: 0, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80", category: "Accessory" },
  { id: "7", name: '24" Monitor (Refurb)', type: "Refurbished", score: 82, bestFor: ["coding", "design"], desc: "1080p IPS, second-screen game-changer.", location: "Glasgow · Pickup", available: true, price: 45, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80", category: "Monitor" },
  { id: "8", name: "Bone-Conduction Headphones", type: "Donated", score: 71, bestFor: ["accessibility"], desc: "Open-ear design — great for sensory comfort.", location: "London · Free delivery", available: true, price: 0, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80", category: "Accessory" },
  { id: "9", name: '"Eloquent JavaScript" Book', type: "Donated", score: 84, bestFor: ["coding"], desc: "Beginner-friendly JS book. Lightly used.", location: "Anywhere · Post", available: true, price: 0, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=800&q=80", category: "Book" },
  { id: "10", name: "Raspberry Pi Starter Kit", type: "Affordable", score: 80, bestFor: ["hardware", "AI"], desc: "Build your first hardware project.", location: "UK wide · Post", available: true, price: 65, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1580983230712-7458b3cd71fe?auto=format&fit=crop&w=800&q=80", category: "Kit" },
  { id: "11", name: "Repair Toolkit", type: "Donated", score: 60, bestFor: ["hardware"], desc: "iFixit-style screwdrivers + spudgers.", location: "Sheffield · Pickup", available: true, price: 0, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?auto=format&fit=crop&w=800&q=80", category: "Kit" },
  { id: "12", name: "Wacom One Tablet", type: "Refurbished", score: 86, bestFor: ["design"], desc: "Pen tablet for digital illustration.", location: "London · Free delivery", available: true, price: 49, link: BASKET_ITEM_LINK, image: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?auto=format&fit=crop&w=800&q=80", category: "Accessory" },
];

function AccessPage() {
  const [step, setStep] = useState<"eligibility" | "result" | "swipe" | "matched">("eligibility");
  const { user, updateUser, awardXp } = useApp();
  const [reason, setReason] = useState("");
  const [city, setCity] = useState((user as any).city || "Birmingham");
  const [urgency, setUrgency] = useState("this month");
  const [basket, setBasket] = useState<Item[]>([]);
  const [showBasket, setShowBasket] = useState(false);
  const [index, setIndex] = useState(0);
  const [filters, setFilters] = useState<{ donated: boolean; refurb: boolean; affordable: boolean; maxPrice: number; category: string }>({
    donated: true, refurb: true, affordable: true, maxPrice: 500, category: "All",
  });
  const [showFilters, setShowFilters] = useState(false);

  const scoredItems = useMemo(() => ITEMS.map((i) => ({ ...i, score: practicalScore(i, user, reason, city).score, scoreBreakdown: practicalScore(i, user, reason, city).breakdown })).sort((a,b)=>b.score-a.score), [user, reason, city]);

  const items = useMemo(() => scoredItems.filter((i) => {
    if (!filters.donated && i.type === "Donated") return false;
    if (!filters.refurb && i.type === "Refurbished") return false;
    if (!filters.affordable && i.type === "Affordable") return false;
    if (i.price > filters.maxPrice) return false;
    if (filters.category !== "All" && i.category !== filters.category) return false;
    return true;
  }), [filters, scoredItems]);

  const current = items[index];
  const swipe = (dir: "left" | "right") => {
    if (!current) return;
    if (dir === "right" && !basket.find((b) => b.id === current.id)) setBasket([...basket, current]);
    setIndex((i) => i + 1);
  };
  const onDragEnd = (_: any, info: PanInfo) => {
    if (info.offset.x > 100) swipe("right");
    else if (info.offset.x < -100) swipe("left");
  };

  const goodReasons = ELIGIBILITY.slice(0, 6);
  const eligible = goodReasons.includes(reason);

  return (
    <div className="min-h-screen pb-20">
      <Navbar />
      <div className="mx-auto mt-10 max-w-5xl px-4">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Tech Hub Access</h1>
            <p className="text-sm text-muted-foreground">Swipe through devices and resources matched to your needs.</p>
          </div>
          {step === "swipe" && (
            <button onClick={() => setShowBasket(true)} className="glass relative rounded-2xl p-3 shadow-elegant transition-all hover:scale-105">
              <ShoppingBasket className="h-5 w-5" />
              {basket.length > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-xs font-bold text-accent-foreground">{basket.length}</span>}
            </button>
          )}
        </div>

        {step === "eligibility" && (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-8 shadow-elegant">
            <h2 className="text-xl font-bold">Why do you need access to tech support?</h2>
            <p className="mt-1 text-sm text-muted-foreground">There's no judgement here — just tell us what's going on.</p>
            <div className="mt-5 space-y-2">
              {ELIGIBILITY.map((r) => (
                <button key={r} onClick={() => setReason(r)}
                  className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left text-sm transition-all ${reason === r ? "border-primary bg-primary/10 glow-primary" : "border-border bg-muted/30 hover:bg-muted/60"}`}>
                  {r} {reason === r && <Check className="h-4 w-4 text-primary" />}
                </button>
              ))}
            </div>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <label className="block"><span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Where are you based?</span><input value={city} onChange={(e)=>setCity(e.target.value)} className="mt-2 w-full rounded-xl border border-border bg-muted/30 px-3 py-2 outline-none focus:ring-2 focus:ring-ring" /></label>
              <div><span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">How urgent is it?</span><div className="mt-2 flex flex-wrap gap-2">{["this week","this month","just exploring"].map((u)=><Toggle key={u} on={urgency===u} onClick={()=>setUrgency(u)}>{u}</Toggle>)}</div></div>
              <div className="md:col-span-2 flex flex-wrap gap-2">{["London","Birmingham","Manchester","Leeds"].map((c)=><button key={c} onClick={()=>setCity(c)} className="rounded-full bg-muted px-3 py-1.5 text-xs hover:bg-muted/70">{c}</button>)}</div>
            </div>
            <button disabled={!reason} onClick={() => { updateUser({ ...(user as any), city } as any); setStep("result"); }}
              className="mt-6 w-full rounded-xl bg-primary py-3 font-semibold text-primary-foreground shadow-elegant glow-primary disabled:opacity-40">
              Continue
            </button>
          </motion.div>
        )}

        {step === "result" && (
          <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="glass rounded-3xl p-8 text-center shadow-elegant">
            <Sparkles className="mx-auto h-10 w-10 text-accent animate-breath" />
            <h2 className="mt-3 text-2xl font-bold">{eligible ? "You may be eligible for Tech Access support." : "Thanks for sharing."}</h2>
            <p className="mt-2 text-muted-foreground">{eligible ? "Let's find what you need." : "We'll still help you explore what's available."}</p>
            <button onClick={() => setStep("swipe")}
              className="mt-6 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground glow-primary">
              Start swiping
            </button>
          </motion.div>
        )}

        {step === "swipe" && (
          <div>
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <button onClick={() => setShowFilters((s) => !s)} className="glass inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm">
                <Filter className="h-4 w-4" /> Filters
              </button>
              <span className="text-xs text-muted-foreground">{items.length} matches</span>
            </div>
            {showFilters && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="glass mb-4 rounded-2xl p-5">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Type</div>
                    <div className="flex flex-wrap gap-2">
                      <Toggle on={filters.donated} onClick={() => setFilters({ ...filters, donated: !filters.donated })}>Donated</Toggle>
                      <Toggle on={filters.refurb} onClick={() => setFilters({ ...filters, refurb: !filters.refurb })}>Refurbished</Toggle>
                      <Toggle on={filters.affordable} onClick={() => setFilters({ ...filters, affordable: !filters.affordable })}>Affordable</Toggle>
                    </div>
                  </div>
                  <div>
                    <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Max price: £{filters.maxPrice}</div>
                    <input type="range" min={0} max={500} step={10} value={filters.maxPrice} onChange={(e) => setFilters({ ...filters, maxPrice: +e.target.value })} className="w-full" />
                  </div>
                  <div className="sm:col-span-2">
                    <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Category</div>
                    <div className="flex flex-wrap gap-2">
                      {["All", "Laptop", "Tablet", "Phone", "Monitor", "Internet", "Accessory", "Book", "Kit"].map((c) => (
                        <Toggle key={c} on={filters.category === c} onClick={() => setFilters({ ...filters, category: c })}>{c}</Toggle>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="relative mx-auto h-[520px] max-w-md">
              <AnimatePresence>
                {current ? (
                  <motion.div
                    key={current.id}
                    drag="x"
                    dragConstraints={{ left: 0, right: 0 }}
                    onDragEnd={onDragEnd}
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ x: 300, opacity: 0, rotate: 15 }}
                    whileDrag={{ rotate: 0 }}
                    className="glass absolute inset-0 cursor-grab overflow-hidden rounded-3xl p-6 shadow-elegant active:cursor-grabbing"
                  >
                    <div className="h-48 overflow-hidden rounded-2xl bg-muted">
                      <img src={current.image} alt={current.name} loading="lazy" className="h-full w-full object-cover" />
                    </div>
                    <div className="mt-4 flex items-start justify-between gap-2">
                      <div>
                        <h3 className="text-xl font-bold">{current.name}</h3>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                          <span className={`rounded-full px-2 py-0.5 font-medium ${current.type === "Donated" ? "bg-accent/20 text-accent" : current.type === "Refurbished" ? "bg-primary/20 text-primary" : "bg-muted text-foreground"}`}>{current.type}</span>
                          <span className="text-muted-foreground">{current.location}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-gradient">{current.score}</div>
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Practical</div>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-muted-foreground">{current.desc}</p>
                    <div className="mt-3 flex flex-wrap gap-1">
                      {current.bestFor.map((b) => <span key={b} className="rounded-full bg-muted px-2 py-0.5 text-xs">{b}</span>)}
                    </div>
                    <div className="mt-3 text-sm font-semibold">{current.price === 0 ? "Free" : `£${current.price}`}</div>
                  </motion.div>
                ) : (
                  <div className="glass flex h-full flex-col items-center justify-center rounded-3xl p-8 text-center">
                    <h3 className="text-xl font-bold">That's everything for now ✨</h3>
                    <p className="mt-2 text-sm text-muted-foreground">Open your basket to review picks.</p>
                    <button onClick={() => { setIndex(0); }} className="mt-4 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">Reset</button>
                  </div>
                )}
              </AnimatePresence>
            </div>

            {current && (
              <div className="mt-6 flex items-center justify-center gap-4">
                <button onClick={() => swipe("left")} aria-label="Not for me"
                  className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-border bg-card transition-all hover:scale-110 hover:border-destructive">
                  <X className="h-7 w-7 text-destructive" />
                </button>
                <button onClick={() => swipe("right")} aria-label="Add to basket"
                  className="flex h-16 w-16 items-center justify-center rounded-full bg-accent text-accent-foreground glow-accent transition-all hover:scale-110">
                  <Heart className="h-7 w-7" />
                </button>
              </div>
            )}
          </div>
        )}

        {step === "matched" && (
          <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="glass rounded-3xl p-10 text-center shadow-elegant">
            <Sparkles className="mx-auto h-12 w-12 text-accent animate-breath" />
            <h2 className="mt-4 text-2xl font-bold">Request received ✦</h2>
            <p className="mx-auto mt-3 max-w-md text-muted-foreground">
              We'll review your request and match you with the best available support based on your needs, location, and learning pathway.
            </p>
            <button onClick={() => { setStep("swipe"); setBasket([]); setShowBasket(false); }} className="mt-6 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground">
              Back to browsing
            </button>
          </motion.div>
        )}
      </div>

      {/* Basket */}
      <AnimatePresence>
        {showBasket && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowBasket(false)} className="fixed inset-0 z-50 bg-background/70 backdrop-blur-sm" />
            <motion.aside initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "spring", damping: 28 }}
              className="fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col border-l border-border bg-card shadow-elegant">
              <div className="flex items-center justify-between border-b border-border p-5">
                <h3 className="text-lg font-bold">Your basket ({basket.length})</h3>
                <button onClick={() => setShowBasket(false)} aria-label="Close" className="rounded-xl p-2 hover:bg-muted"><X className="h-5 w-5" /></button>
              </div>
              <div className="flex-1 space-y-4 overflow-y-auto p-5">
                {basket.length === 0 && <p className="text-center text-sm text-muted-foreground">Swipe right on items you'd like.</p>}
                {basket.map((b) => (
                  <div key={b.id} className="rounded-2xl border border-border bg-muted/30 p-4">
                    <div className="flex items-start gap-3">
                      <img src={b.image} alt={b.name} loading="lazy" className="h-14 w-14 shrink-0 rounded-xl object-cover" />
                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <a href={BASKET_ITEM_LINK} target="_blank" rel="noopener noreferrer" className="font-semibold hover:text-accent hover:underline">{b.name}</a>
                          <button onClick={() => setBasket(basket.filter((x) => x.id !== b.id))} aria-label="Remove" className="text-muted-foreground hover:text-destructive"><X className="h-4 w-4" /></button>
                        </div>
                        <div className="mt-1 text-xs text-muted-foreground">{b.type} · {b.location}</div>
                        <div className="mt-2 text-xs">Practical score <span className="font-bold text-gradient">{b.score}/100</span> — {(b as any).scoreBreakdown?.join(" · ") || `fit for ${b.bestFor.join(", ")}`}.</div>
                        <a href={BASKET_ITEM_LINK} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-accent hover:underline">More info <ExternalLink className="h-3 w-3" /></a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {basket.length > 0 && (
                <div className="border-t border-border p-5">
                  <button onClick={() => { const id = `REQ-${Math.random().toString(36).slice(2,7).toUpperCase()}`; updateUser({ deviceRequests: [...(user.deviceRequests || []), { id, items: basket.map(b=>b.name), reason, urgency, location: city, createdAt: new Date().toISOString() }] }); awardXp(`device-request:${id}`,25,"Device request"); setShowBasket(false); setStep("matched"); }} className="w-full rounded-xl bg-accent py-3 font-semibold text-accent-foreground glow-accent">
                    Request Match
                  </button>
                </div>
              )}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}


function practicalScore(item: Item, user: any, reason: string, city: string) {
  let score = 0; const breakdown: string[] = [];
  const interests = (user.interests || []).map((x:string)=>x.toLowerCase());
  if (item.bestFor.some(b => interests.some((i:string)=>b.toLowerCase().includes(i) || i.includes(b.toLowerCase())))) { score += 30; breakdown.push("+30 matches your interests"); }
  if (item.bestFor.some(b => (user.dreamCareer || "").toLowerCase().includes(b.toLowerCase()))) { score += 25; breakdown.push("+25 supports your pathway"); }
  if (city && item.location.toLowerCase().startsWith(city.toLowerCase())) { score += 20; breakdown.push(`+20 in ${city}`); }
  if ((reason.includes("laptop") || reason.includes("share") || reason.includes("afford")) && item.category === "Laptop") { score += 15; breakdown.push("+15 covers your device gap"); }
  if (item.type === "Donated" && reason.toLowerCase().includes("afford")) { score += 10; breakdown.push("+10 donated support"); }
  if (item.bestFor.includes("accessibility") && user.accessibility !== "none") { score += 5; breakdown.push("+5 accessibility match"); }
  return { score: Math.min(100, Math.max(score, item.score - 20)), breakdown };
}

function Toggle({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all ${on ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>
      {children}
    </button>
  );
}
