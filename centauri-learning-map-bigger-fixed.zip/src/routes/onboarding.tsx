import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { ArrowLeft, ArrowRight, Check, Upload, Sparkles } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { RequireAuth } from "@/components/RequireAuth";
import { useApp, type AccessibilityMode } from "@/lib/app-state";
import { CAREER_PATHS } from "@/lib/careers";
import { parseCvForDemo } from "@/lib/cv.functions";

export const Route = createFileRoute("/onboarding")({
  component: () => <RequireAuth><Onboarding /></RequireAuth>,
  head: () => ({ meta: [{ title: "Onboarding — Centauri Learning" }, { name: "description", content: "Tell us a bit about you so we can build your tech pathway." }] }),
});

const INTERESTS = ["Coding", "Web development", "AI", "Cybersecurity", "UX/UI design", "Video editing", "Digital marketing", "Game development", "Hardware / repair", "Not sure yet"];
const CONFIDENCE = ["I'm completely new", "I know a little", "I've built small things before", "I feel confident but need guidance", "I'm ready for opportunities"];
const DEVICES = ["I have my own laptop", "I share a laptop", "I only have a phone", "I have a tablet", "I have unreliable internet", "I have no reliable device", "I need help accessing equipment"];
const A11Y: { label: string; value: AccessibilityMode }[] = [
  { label: "Dyslexia-friendly mode", value: "dyslexia" },
  { label: "ADHD focus mode", value: "adhd" },
  { label: "Autism / sensory-friendly mode", value: "autism" },
  { label: "Visual support mode", value: "visual" },
  { label: "Anxiety / confidence support mode", value: "anxiety" },
  { label: "No adjustments needed", value: "none" },
  { label: "Prefer not to say", value: "prefer-not" },
];

function Onboarding() {
  const nav = useNavigate();
  const { updateUser, user, session } = useApp();
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    name: user.name || (session?.user.user_metadata?.name as string) || "",
    dreamCareers: user.dreamCareer ? [user.dreamCareer] : [] as string[],
    interests: [] as string[],
    confidence: "",
    devices: [] as string[],
    accessibility: "none" as AccessibilityMode,
    cvName: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const toggle = (key: "interests" | "devices", v: string) => {
    setData((d) => ({ ...d, [key]: d[key].includes(v) ? d[key].filter((x) => x !== v) : [...d[key], v] }));
  };

  const toggleCareer = (id: string) => {
    setData((d) => {
      if (d.dreamCareers.includes(id)) return { ...d, dreamCareers: d.dreamCareers.filter((x) => x !== id) };
      if (d.dreamCareers.length >= 2) return d;
      return { ...d, dreamCareers: [...d.dreamCareers, id] };
    });
  };

  const validateStep = (s: number): boolean => {
    const e: Record<string, string> = {};
    if (s === 0) {
      if (!data.name.trim()) e.name = "Please share your name.";
      if (data.dreamCareers.length === 0) e.dreamCareer = "Pick at least one dream career (up to 2).";
    }
    if (s === 1 && data.interests.length === 0) e.interests = "Pick at least one interest.";
    if (s === 2 && !data.confidence) e.confidence = "Please pick the option that best fits you.";
    if (s === 3 && data.devices.length === 0) e.devices = "Pick at least one option that describes your setup.";
    if (s === 5 && !data.cvName) e.cv = "Please upload your CV to continue.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (!validateStep(step)) return;
    if (step < 5) setStep(step + 1);
    else finish();
  };
  const back = () => step > 0 && setStep(step - 1);

  const finish = async () => {
    const cvParsed = data.cvName ? await parseCvForDemo(data.cvName) : undefined;
    updateUser({
      name: data.name, email: session?.user.email ?? "",
      dreamCareer: data.dreamCareers[0],
      interests: data.interests, confidence: data.confidence,
      devices: data.devices, accessibility: data.accessibility,
      cvUploaded: !!data.cvName, cvName: data.cvName || undefined,
      cvParsed,
    });
    nav({ to: "/" });
  };

  const steps = ["You", "Interests", "Confidence", "Access", "Accessibility", "CV"];

  return (
    <div className="min-h-screen pb-20">
      <Navbar />
      <div className="mx-auto mt-10 max-w-2xl px-4">
        <div className="mb-6 flex items-center gap-2 text-xs text-muted-foreground">
          {steps.map((s, i) => (
            <div key={s} className="flex flex-1 items-center gap-2">
              <div className={`h-1.5 flex-1 rounded-full transition-all ${i <= step ? "bg-primary glow-primary" : "bg-muted"}`} />
            </div>
          ))}
        </div>
        <div className="mb-2 text-sm text-muted-foreground">Step {step + 1} of 6 · {steps[step]}</div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35 }}
            className="glass rounded-3xl p-8 shadow-elegant"
          >
            {step === 0 && (
              <div className="space-y-5">
                <h2 className="text-2xl font-bold">Let's get to know you.</h2>
                <p className="text-sm text-muted-foreground">You don't need to know everything yet — we'll meet you where you are.</p>
                <Field label="What should we call you?" error={errors.name}>
                  <input value={data.name} onChange={(e) => setData({ ...data, name: e.target.value })}
                    className="input" placeholder="Alex Johnson" />
                </Field>
                <Field label="What is your dream career path?" error={errors.dreamCareer} hint="Pick up to 2 — we'll shape your pathway around them.">
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {CAREER_PATHS.map((c) => {
                      const active = data.dreamCareers.includes(c.id);
                      const disabled = !active && data.dreamCareers.length >= 2;
                      return (
                        <button key={c.id} type="button"
                          disabled={disabled}
                          onClick={() => toggleCareer(c.id)}
                          className={`flex flex-col items-center justify-center gap-1.5 rounded-xl border p-3 text-center text-sm transition-all ${
                            active ? "border-primary bg-primary/10 glow-primary"
                              : disabled ? "border-border bg-muted/20 opacity-40 cursor-not-allowed"
                              : "border-border bg-muted/30 hover:bg-muted/60"
                          }`}>
                          <span className="text-2xl">{c.emoji}</span>
                          <span className="font-semibold leading-tight">{c.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </Field>
              </div>
            )}

            {step === 1 && (
              <div>
                <h2 className="text-2xl font-bold">What sparks your interest?</h2>
                <p className="mt-1 text-sm text-muted-foreground">Pick as many as you'd like — at least one.</p>
                <div className="mt-5 grid grid-cols-2 gap-2">
                  {INTERESTS.map((i) => <Chip key={i} active={data.interests.includes(i)} onClick={() => toggle("interests", i)}>{i}</Chip>)}
                </div>
                {errors.interests && <p className="mt-3 text-sm text-destructive">{errors.interests}</p>}
              </div>
            )}

            {step === 2 && (
              <div>
                <h2 className="text-2xl font-bold">How confident do you feel right now?</h2>
                <p className="mt-1 text-sm text-muted-foreground">There's no wrong answer.</p>
                <div className="mt-5 space-y-2">
                  {CONFIDENCE.map((c) => (
                    <Option key={c} active={data.confidence === c} onClick={() => setData({ ...data, confidence: c })}>{c}</Option>
                  ))}
                </div>
                {errors.confidence && <p className="mt-3 text-sm text-destructive">{errors.confidence}</p>}
              </div>
            )}

            {step === 3 && (
              <div>
                <h2 className="text-2xl font-bold">What's your setup like?</h2>
                <p className="mt-1 text-sm text-muted-foreground">This helps us recommend the right devices and resources.</p>
                <div className="mt-5 grid gap-2">
                  {DEVICES.map((d) => <Chip key={d} active={data.devices.includes(d)} onClick={() => toggle("devices", d)}>{d}</Chip>)}
                </div>
                {errors.devices && <p className="mt-3 text-sm text-destructive">{errors.devices}</p>}
              </div>
            )}

            {step === 4 && (
              <div>
                <h2 className="text-2xl font-bold">How can we make Centauri Learning easier for you to use?</h2>
                <p className="mt-1 text-sm text-muted-foreground">Optional, private, and you can change it any time.</p>
                <div className="mt-5 space-y-2">
                  {A11Y.map((a) => (
                    <Option key={a.value} active={data.accessibility === a.value} onClick={() => setData({ ...data, accessibility: a.value })}>
                      <div className="font-medium">{a.label}</div>
                    </Option>
                  ))}
                </div>
              </div>
            )}

            {step === 5 && (
              <div>
                <h2 className="text-2xl font-bold">Upload your CV so we can personalise your pathway.</h2>
                <p className="mt-1 text-sm text-muted-foreground">PDF, DOC or DOCX. This step is required — even a rough draft is fine.</p>
                <label className="mt-5 flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border bg-muted/30 p-10 text-center transition-all hover:border-primary hover:bg-muted/60">
                  <Upload className="h-8 w-8 text-primary" />
                  <div className="text-sm">
                    {data.cvName ? <span className="font-medium">{data.cvName}</span> : "Click to upload your CV"}
                  </div>
                  <input type="file" accept=".pdf,.doc,.docx" className="hidden"
                    onChange={(e) => { setData({ ...data, cvName: e.target.files?.[0]?.name || "" }); setErrors({}); }} />
                </label>
                {errors.cv && <p className="mt-2 text-sm text-destructive">{errors.cv}</p>}
              </div>
            )}

            <div className="mt-8 flex items-center justify-between">
              <button onClick={back} disabled={step === 0}
                className="inline-flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-sm font-medium text-muted-foreground transition-all hover:text-foreground disabled:opacity-40">
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <button onClick={next}
                className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-elegant glow-primary transition-all hover:scale-105">
                {step === 5 ? <>Finish <Sparkles className="h-4 w-4" /></> : <>Continue <ArrowRight className="h-4 w-4" /></>}
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

function Field({ label, error, hint, children }: { label: string; error?: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-muted-foreground">{hint}</span>}
      {error && <span className="mt-1 block text-xs text-accent">{error}</span>}
      <style>{`.input{width:100%;border-radius:0.75rem;background:var(--muted);border:1px solid var(--border);padding:0.7rem 0.9rem;font-size:0.95rem;outline:none;transition:all .2s}.input:focus{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklch, var(--ring) 25%, transparent)}`}</style>
    </label>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick}
      className={`flex items-center justify-between gap-2 rounded-xl border px-4 py-3 text-left text-sm transition-all ${
        active ? "border-primary bg-primary/10 text-foreground glow-primary" : "border-border bg-muted/40 hover:bg-muted"
      }`}>
      <span>{children}</span>
      {active && <Check className="h-4 w-4 text-primary" />}
    </button>
  );
}

function Option({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick}
      className={`flex w-full items-center justify-between gap-3 rounded-xl border px-4 py-3 text-left transition-all ${
        active ? "border-primary bg-primary/10 glow-primary" : "border-border bg-muted/30 hover:bg-muted/60"
      }`}>
      <div className="text-sm">{children}</div>
      {active && <Check className="h-4 w-4 text-primary" />}
    </button>
  );
}
