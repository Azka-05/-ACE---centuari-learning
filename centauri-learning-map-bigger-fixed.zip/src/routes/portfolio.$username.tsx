import { createFileRoute, Link } from "@tanstack/react-router";
import { ExternalLink, Share2, Star } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { useApp } from "@/lib/app-state";
import { levelFromXp } from "@/lib/gamification";

export const Route = createFileRoute("/portfolio/$username")({ component: PortfolioPage, head: () => ({ meta: [{ title: "Portfolio — Centauri Learning" }] }) });

function PortfolioPage() {
  const { username } = Route.useParams();
  const { user } = useApp();
  const { level } = levelFromXp(user.xp || 0);
  const projects = user.projects || [];
  return <div className="min-h-screen pb-20"><Navbar/><main className="mx-auto mt-10 max-w-5xl px-4"><header className="glass rounded-3xl p-8 shadow-elegant"><div className="flex flex-wrap items-center justify-between gap-4"><div><div className="text-xs font-bold uppercase tracking-[0.25em] text-accent">Public portfolio</div><h1 className="mt-2 text-4xl font-black">{user.name || username}</h1><p className="mt-1 text-muted-foreground">Dream career: {user.dreamCareer || "Tech"} · Level {level}</p></div><div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-primary/30 to-accent/30"><Star className="h-10 w-10 fill-accent text-accent"/></div></div><button onClick={()=>navigator.clipboard?.writeText(location.href)} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground"><Share2 className="h-4 w-4"/> Share portfolio</button></header>{projects.length ? <section className="mt-8 grid gap-5 md:grid-cols-3">{projects.map(p=><article key={p.id} className="glass rounded-3xl p-5 shadow-elegant"><div className="flex h-32 items-center justify-center rounded-2xl bg-muted/50"><ExternalLink className="h-9 w-9 text-accent"/></div><h2 className="mt-4 font-bold">{p.title}</h2><p className="mt-1 text-xs text-muted-foreground">Submitted {new Date(p.submittedAt).toLocaleDateString()}</p><a href={p.deliverableUrl} target="_blank" className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-accent hover:underline">View deliverable <ExternalLink className="h-3 w-3"/></a></article>)}</section> : <div className="mt-8 rounded-3xl border border-dashed border-border p-10 text-center text-muted-foreground">No projects shipped yet — come back soon.</div>}<Link to="/explore" className="mt-8 inline-block text-sm font-semibold text-accent hover:underline">Back to learning</Link></main></div>;
}
