import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { LogOut, User, Mail, Sparkles, Accessibility, FileText, Share2 } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { useApp, type AccessibilityMode } from "@/lib/app-state";

export const Route = createFileRoute("/account")({
  component: AccountPage,
  head: () => ({ meta: [{ title: "Account settings — Centauri Learning" }] }),
});

const A11Y: { label: string; value: AccessibilityMode }[] = [
  { label: "No adjustments needed", value: "none" },
  { label: "Dyslexia-friendly mode", value: "dyslexia" },
  { label: "ADHD focus mode", value: "adhd" },
  { label: "Autism / sensory-friendly mode", value: "autism" },
  { label: "Visual support mode", value: "visual" },
  { label: "Anxiety / confidence support mode", value: "anxiety" },
  { label: "Prefer not to say", value: "prefer-not" },
];

function AccountPage() {
  const { user, updateUser, session, authReady, signOut, theme } = useApp();
  const nav = useNavigate();

  useEffect(() => {
    if (authReady && !session) nav({ to: "/auth" });
  }, [authReady, session, nav]);

  const handleLogout = async () => {
    await signOut();
    nav({ to: "/" });
  };

  return (
    <div className="min-h-screen pb-20">
      <Navbar />
      <div className="mx-auto mt-10 max-w-2xl space-y-6 px-4">
        <div>
          <h1 className="text-3xl font-bold">Account settings</h1>
          <p className="mt-1 text-sm text-muted-foreground">Update your details and how Centauri Learning feels.</p>
        </div>

        <Section title="Profile" icon={<User className="h-4 w-4" />}>
          <Row label="Name">
            <input value={user.name} onChange={(e) => updateUser({ name: e.target.value })}
              className="settings-input" placeholder="Your name" />
          </Row>
          <Row label="Email" icon={<Mail className="h-4 w-4 text-muted-foreground" />}>
            <input value={session?.user.email ?? user.email} disabled className="settings-input opacity-60" />
          </Row>
        </Section>

        <Section title="Appearance" icon={<Sparkles className="h-4 w-4" />}>
          <p className="text-sm text-muted-foreground">Current theme: <span className="font-medium text-foreground">{theme === "dark" ? "Dark" : "Light"}</span>. Use the toggle in the top bar to switch.</p>
        </Section>

        <Section title="Accessibility" icon={<Accessibility className="h-4 w-4" />}>
          <p className="mb-3 text-sm text-muted-foreground">Choose how Centauri Learning adapts for you. Changes apply instantly.</p>
          <div className="grid gap-2">
            {A11Y.map((a) => (
              <button key={a.value} onClick={() => updateUser({ accessibility: a.value })}
                className={`rounded-xl border px-4 py-2.5 text-left text-sm transition-all ${
                  user.accessibility === a.value
                    ? "border-primary bg-primary/10"
                    : "border-border bg-muted/30 hover:bg-muted/60"
                }`}>
                {a.label}
              </button>
            ))}
          </div>
        </Section>

        <Section title="Portfolio" icon={<Share2 className="h-4 w-4" />}>
          <p className="text-sm text-muted-foreground">Share your shipped projects as proof of growth.</p>
          <button onClick={() => navigator.clipboard?.writeText(`${location.origin}/portfolio/${slug(user.name || "learner")}`)} className="mt-3 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Copy public portfolio URL</button>
        </Section>

        <Section title="Your CV" icon={<FileText className="h-4 w-4" />}>
          <p className="text-sm text-muted-foreground">
            {user.cvName ? <>Uploaded: <span className="font-medium text-foreground">{user.cvName}</span></> : "No CV on file."}
          </p>
          <Link to="/onboarding" className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-accent hover:underline">
            Update onboarding & CV
          </Link>
        </Section>

        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-5">
          <h2 className="font-semibold">Log out</h2>
          <p className="mt-1 text-sm text-muted-foreground">You'll need to sign back in to continue your pathway.</p>
          <button onClick={handleLogout}
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-destructive px-4 py-2.5 text-sm font-semibold text-destructive-foreground transition-all hover:opacity-90">
            <LogOut className="h-4 w-4" /> Log out
          </button>
        </div>
      </div>
      <style>{`.settings-input{width:100%;border-radius:0.75rem;background:var(--muted);border:1px solid var(--border);padding:0.6rem 0.85rem;font-size:0.95rem;outline:none;transition:all .2s}.settings-input:focus{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklch, var(--ring) 25%, transparent)}`}</style>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card/60 p-5">
      <h2 className="mb-3 inline-flex items-center gap-2 font-semibold">{icon}{title}</h2>
      <div className="space-y-3">{children}</div>
    </div>
  );
}
function Row({ label, icon, children }: { label: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground">{icon}{label}</span>
      {children}
    </label>
  );
}

function slug(v: string) { return v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "learner"; }
