import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useMemo } from "react";
import { ArrowRight, Shield, Users, Compass, Clock, Zap, Flame, Sparkles } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { StarMascot } from "@/components/StarMascot";
import { StarProgress } from "@/components/StarProgress";
import { ListenButton } from "@/components/ListenButton";
import { useApp } from "@/lib/app-state";
import { getCareer, allNodes } from "@/lib/careers";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "Centauri Learning — ACE Your Learning" },
      { name: "description", content: "Access. Connect. Explore. A calm, personalised pathway into technology — built for potential, not privilege." },
      { property: "og:title", content: "Centauri Learning — ACE Your Learning" },
      { property: "og:description", content: "Access opportunity. Connect with people. Explore your future." },
    ],
  }),
});

function Home() {
  const { session, hasOnboarded } = useApp();
  if (!session || !hasOnboarded) return <Landing />;
  return <Dashboard />;
}

// =================== LANDING (guest) ===================
const PILLARS = [
  {
    letter: "A", title: "Access", icon: Shield,
    body: "Devices, internet, and opportunities — matched to where you are right now. No laptop? No network? No problem.",
    points: ["Devices & affordable kit", "Free learning resources", "Real-world opportunities"],
  },
  {
    letter: "C", title: "Connect", icon: Users,
    body: "Mentors who share your story. A community that wants you to win. Warm intros, not cold applications.",
    points: ["Matched mentors", "Peer community", "Industry professionals"],
  },
  {
    letter: "E", title: "Explore", icon: Compass,
    body: "A calm pathway through coding, design, cyber, AI and creative tech. Small steps, every day.",
    points: ["Skill pathways", "Daily tasks", "Your future, on your terms"],
  },
];

function Landing() {
  const { session, hasOnboarded } = useApp();
  const primaryTo = session ? (hasOnboarded ? "/" : "/onboarding") : "/auth";
  const primaryLabel = session ? (hasOnboarded ? "Open Dashboard" : "Continue Onboarding") : "Start Your Journey";
  return (
    <div className="min-h-screen bg-hero">
      <Navbar />
      <section className="mx-auto grid max-w-6xl items-center gap-12 px-4 pt-16 pb-20 md:grid-cols-2 md:pt-24">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
          <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground">
            Centauri Learning · ACE
          </span>
          <h1 className="mt-6 text-5xl font-bold leading-tight md:text-7xl">
            <span className="text-gradient">ACE</span> Your Learning.
          </h1>
          <p className="mt-5 max-w-md text-base text-muted-foreground md:text-lg">
            Access opportunity. Connect with people. Explore your future. <br />
            Your pathway into technology starts here.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to={primaryTo}
              className="group inline-flex items-center gap-2 rounded-2xl bg-primary px-7 py-4 text-base font-semibold text-primary-foreground shadow-elegant glow-primary transition-all hover:scale-105">
              {primaryLabel}
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Link>
            <a href="#what-is-ace" className="glass inline-flex items-center gap-2 rounded-2xl px-7 py-4 text-base font-medium transition-all hover:scale-105">
              What is ACE?
            </a>
          </div>
          <div className="mt-10"><StarMascot message="Built for potential, not privilege." /></div>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.1 }}
          className="grid grid-cols-1 gap-4">
          {[
            { letter: "A", title: "Access", body: "Devices, networks and opportunities — for everyone.", icon: Shield },
            { letter: "C", title: "Connect", body: "Mentors and community who walked this path before you.", icon: Users },
            { letter: "E", title: "Explore", body: "A calm, personalised pathway into your dream career.", icon: Compass },
          ].map((p, i) => (
            <motion.div key={p.letter} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.1 }}
              className="glass flex items-center gap-4 rounded-3xl p-5 shadow-elegant">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/30 to-accent/30 font-display text-3xl font-bold text-primary">
                {p.letter}
              </div>
              <div>
                <div className="flex items-center gap-2 font-semibold"><p.icon className="h-4 w-4 text-accent" />{p.title}</div>
                <div className="mt-0.5 text-sm text-muted-foreground">{p.body}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* =============== WHAT IS ACE / About =============== */}
      <section id="what-is-ace" className="mx-auto max-w-4xl px-4 pt-10 text-center scroll-mt-24">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
          <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-accent" /> What is ACE?
          </span>
          <h2 className="mt-5 text-4xl font-bold leading-tight md:text-6xl">
            <span className="text-gradient">ACE</span> Your Learning
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base text-muted-foreground md:text-lg">
            Centauri Learning is built around three pillars — Access, Connect, Explore.
            A calm pathway into technology for young people, built for potential, not privilege.
          </p>
        </motion.div>
      </section>

      <section className="mx-auto mt-12 grid max-w-6xl gap-6 px-4 md:grid-cols-3">
        {PILLARS.map((p, i) => (
          <motion.div key={p.letter}
            initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.12 }}
            whileHover={{ y: -6 }}
            className="glass group relative overflow-hidden rounded-3xl p-7 shadow-elegant">
            <motion.div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-accent/10 blur-3xl"
              animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.7, 0.4] }}
              transition={{ duration: 5, repeat: Infinity, delay: i * 0.5 }} />
            <div className="relative">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/30 to-accent/30 font-display text-3xl font-bold text-primary">
                  {p.letter}
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">Pillar {i + 1}</div>
                  <h3 className="text-2xl font-semibold">{p.title}</h3>
                </div>
              </div>
              <p className="mt-4 text-sm text-muted-foreground">{p.body}</p>
              <ul className="mt-4 space-y-1.5 text-sm">
                {p.points.map((pt) => (
                  <li key={pt} className="flex items-center gap-2">
                    <p.icon className="h-3.5 w-3.5 text-accent" /> {pt}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </section>

      <section className="mx-auto mt-16 max-w-3xl px-4">
        <motion.div initial={{ opacity: 0, scale: 0.96 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
          className="glass rounded-3xl p-8 text-center shadow-elegant md:p-12">
          <h2 className="text-2xl font-bold md:text-3xl">No laptop? No network? No problem.</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Centauri Learning helps you access tools, build confidence, and discover real pathways into tech —
            even if you're starting with nothing but curiosity.
          </p>
        </motion.div>
      </section>

      <section className="mx-auto mt-16 mb-24 max-w-3xl px-4 text-center">
        <Link to={primaryTo}
          className="group inline-flex items-center gap-2 rounded-2xl bg-primary px-8 py-4 text-lg font-semibold text-primary-foreground shadow-elegant glow-primary transition-all hover:scale-105">
          Start Your Journey
          <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
        </Link>
        <p className="mt-4 text-xs text-muted-foreground">Free, always. Built for everyone.</p>
      </section>
    </div>
  );
}

// =================== DASHBOARD (signed in) ===================
const QUOTES = [
  "Progress beats perfection.",
  "You're building momentum.",
  "Keep showing up.",
  "Small steps still move you forward.",
  "You're closer than you think.",
];

function Dashboard() {
  const { user } = useApp();
  const nav = useNavigate();
  const career = getCareer(user.dreamCareer);
  const nodes = useMemo(() => allNodes(career), [career]);
  const completed = new Set(user.completedLessons);

  const dayIndex = Math.floor(Date.now() / 86400000);
  const todoNodes = nodes.filter((n) => !completed.has(n.id));
  const today = todoNodes[0] ?? nodes[0];
  const tomorrow = todoNodes[1] ?? nodes[(nodes.indexOf(today) + 1) % nodes.length];
  const quote = QUOTES[dayIndex % QUOTES.length];

  const minutes = (n: { xp: number }) => Math.max(8, Math.round(n.xp / 4));

  return (
    <div className="min-h-screen bg-hero pb-28 md:pb-20">
      <Navbar />
      <div className="mx-auto mt-6 max-w-5xl px-4 sm:mt-10">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-center">
          <div className="text-xs font-semibold uppercase tracking-[0.25em] text-accent">
            Welcome back, {user.name?.split(" ")[0] || "explorer"}
          </div>
          <h1 className="mt-3 text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            <span className="text-gradient">{career.emoji} {career.name}</span> pathway
          </h1>
          <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
            One small step today. A bigger future tomorrow.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-4">
            <StarProgress size={138} />
            <span className="inline-flex items-center gap-1 rounded-full border border-border/60 bg-muted/30 px-4 py-2 text-xs font-semibold"><Flame className="h-3 w-3 text-accent" /> {user.streak || 0} day streak</span>
          </div>
        </motion.div>

        <motion.button
          onClick={() => nav({ to: "/explore" })}
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15 }}
          whileHover={{ scale: 1.01 }}
          className="surface group relative mx-auto mt-8 block w-full max-w-3xl overflow-hidden rounded-3xl p-5 text-left shadow-elegant sm:mt-10 sm:p-8">
          <div className="absolute -right-20 -top-20 h-52 w-52 rounded-full bg-accent/10 blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-accent">
              <Zap className="h-3.5 w-3.5" /> Today's Task
            </div>
            <h3 className="mt-3 text-2xl font-bold leading-tight sm:text-3xl md:text-4xl">{today.title}</h3>
            <p className="mt-3 max-w-xl text-base text-muted-foreground">{today.blurb}</p>
            <div className="mt-4" onClick={(e) => e.stopPropagation()}>
              <ListenButton text={`Today's mission: ${today.title}. ${today.blurb}`} label="Listen instead" />
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-2 text-xs">
              <span className="inline-flex items-center gap-1 rounded-full bg-muted/60 px-3 py-1"><Clock className="h-3 w-3" /> {minutes(today)} mins</span>
              <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-3 py-1 font-semibold text-primary">+{today.xp} XP</span>
              <span className="rounded-full bg-accent/15 px-3 py-1 font-medium text-accent">{career.name}</span>
              {completed.has(today.id) && <span className="rounded-full bg-emerald-500/15 px-3 py-1 text-emerald-500">Done</span>}
            </div>
            <div className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground glow-primary transition-transform group-hover:translate-x-1">
              Continue learning <ArrowRight className="h-4 w-4" />
            </div>
          </div>
        </motion.button>

        <div className="mx-auto mt-5 grid max-w-3xl gap-3 sm:gap-4 md:grid-cols-3">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
            className="surface rounded-2xl p-4 shadow-elegant">
            <div className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Up next</div>
            <div className="mt-1.5 font-semibold leading-snug">{tomorrow.title}</div>
            <div className="mt-1 text-xs text-muted-foreground">{minutes(tomorrow)} mins · +{tomorrow.xp} XP</div>
          </motion.div>

          <motion.button onClick={() => nav({ to: "/connections" })}
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="surface rounded-2xl p-4 text-left shadow-elegant transition-transform hover:scale-[1.02]">
            <div className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Connect</div>
            <div className="mt-1.5 font-semibold">Find a mentor</div>
            <div className="mt-1 text-xs text-muted-foreground">People who walked this path</div>
          </motion.button>

          <motion.button onClick={() => nav({ to: "/access" })}
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
            className="surface rounded-2xl p-4 text-left shadow-elegant transition-transform hover:scale-[1.02]">
            <div className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Access</div>
            <div className="mt-1.5 font-semibold">Support & resources</div>
            <div className="mt-1 text-xs text-muted-foreground">Devices, networks, opportunities</div>
          </motion.button>
        </div>

        <div className="mx-auto mt-8 flex max-w-3xl justify-center">
          <StarMascot message={quote} size={48} />
        </div>
      </div>
    </div>
  );
}
