import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Linkedin, Star, Sparkles } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { RequireAuth } from "@/components/RequireAuth";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/connections")({
  component: () => <RequireAuth requireOnboarding><ConnectionsPage /></RequireAuth>,
  head: () => ({ meta: [{ title: "Connections — Centauri Learning" }, { name: "description", content: "Meet mentors and grow your network." }] }),
});

type Profile = {
  id: string;
  name: string;
  role: string;
  image: string;
  linkedin: string;
  available?: string;
};

const MENTOR_MATCHES: Profile[] = [
  { id: "hamza", name: "Hamza Wahbi", role: "Engineer & mentor", image: "/mentors/hamza.png", linkedin: "https://www.linkedin.com/in/hamzawahbi/", available: "Available this week" },
  { id: "mohamed", name: "Mohamed H Bano", role: "Centauri team", image: "/mentors/mohamed.png", linkedin: "https://www.linkedin.com/in/mohamed-h-bano-9b3894271/", available: "Usually replies fast" },
  { id: "jabril", name: "Jabril Aden", role: "Founder at Centauri", image: "/mentors/jabril.png", linkedin: "https://www.linkedin.com/in/jabril-aden/?skipRedirect=true", available: "Mentor match" },
];

const RECOMMENDED: Profile[] = [
  { id: "kulsoom", name: "Kulsoom Alim", role: "Tech pathway mentor", image: "/mentors/kulsoom.png", linkedin: "https://www.linkedin.com/in/kulsoom-alim-b63099339/?skipRedirect=true", available: "Recommended for you" },
  { id: "azka", name: "Azka Hussain", role: "Computer Science student", image: "/mentors/azka.png", linkedin: "https://www.linkedin.com/in/azka-hussain-9768822b3", available: "Peer support" },
];

function ConnectionsPage() {
  return (
    <div className="min-h-screen pb-28 md:pb-16">
      <Navbar />
      <main className="mx-auto mt-6 w-full max-w-6xl px-4 sm:mt-10">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-3xl text-center sm:text-left md:mx-0">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/30 px-3 py-1 text-xs font-semibold text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-accent" /> Support network
          </div>
          <h1 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">Connections & Mentorship</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground sm:text-base">
            Start with a simple LinkedIn connection. These people can help you understand the pathway, ask better questions, and feel less alone.
          </p>
        </motion.div>

        <Section title="3 mentor matches" iconTone="text-accent" profiles={MENTOR_MATCHES} />
        <Section title="Recommended for you" iconTone="text-primary" profiles={RECOMMENDED} compact />
      </main>
    </div>
  );
}

function Section({ title, profiles, compact = false, iconTone }: { title: string; profiles: Profile[]; compact?: boolean; iconTone: string }) {
  return (
    <section className="mt-8 sm:mt-10">
      <div className="mb-4 flex items-center gap-2">
        <Star className={`h-5 w-5 ${iconTone}`} />
        <h2 className="text-xl font-semibold">{title}</h2>
      </div>
      <div className={`grid gap-4 ${compact ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"}`}>
        {profiles.map((profile, index) => <ProfileCard key={profile.id} profile={profile} delay={index * 0.04} />)}
      </div>
    </section>
  );
}

function ProfileCard({ profile, delay }: { profile: Profile; delay: number }) {
  const { awardXp } = useApp();
  const connect = () => {
    awardXp(`mentor-connect:${profile.id}`, 20, "Connection made");
    window.open(profile.linkedin, "_blank", "noopener,noreferrer");
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="surface group flex h-full flex-col items-center overflow-hidden rounded-3xl p-4 text-center shadow-elegant transition-transform hover:-translate-y-1"
    >
      <div className="h-32 w-32 overflow-hidden rounded-2xl bg-muted sm:h-36 sm:w-36">
        <img src={profile.image} alt={`${profile.name} profile`} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
      </div>
      <div className="flex w-full flex-1 flex-col px-1 pb-1 pt-4">
        <div className="flex min-h-[74px] items-start justify-center">
          <div className="min-w-0">
            <h3 className="truncate text-lg font-bold leading-tight">{profile.name}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{profile.role}</p>
          </div>
        </div>
        {profile.available && <p className="mt-2 text-xs font-medium text-muted-foreground">{profile.available}</p>}
        <button
          onClick={connect}
          className="mt-auto inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl bg-[#0a66c2] px-4 py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90 focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Linkedin className="h-4 w-4" /> Connect on LinkedIn
        </button>
      </div>
    </motion.article>
  );
}
