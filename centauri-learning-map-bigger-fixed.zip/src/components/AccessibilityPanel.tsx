import { useEffect, useState } from "react";
import { Accessibility, Type, Eye, Sparkles, MousePointer2, BookOpen } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";

export type FontScale = "sm" | "md" | "lg" | "xl";

export interface A11yPrefs {
  fontScale: FontScale;
  reducedMotion: boolean;
  highContrast: boolean;
  dyslexiaFont: boolean;
}

const DEFAULTS: A11yPrefs = {
  fontScale: "md",
  reducedMotion: false,
  highContrast: false,
  dyslexiaFont: false,
};

const STORAGE_KEY = "centauri.a11y";

function load(): A11yPrefs {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {}
  return DEFAULTS;
}

function apply(p: A11yPrefs) {
  const root = document.documentElement;
  root.dataset.fontScale = p.fontScale;
  root.classList.toggle("a11y-reduced-motion", p.reducedMotion);
  root.classList.toggle("a11y-high-contrast", p.highContrast);
  root.classList.toggle("a11y-dyslexia", p.dyslexiaFont);
}

/** Mount once at app root to hydrate stored prefs on first paint. */
export function useA11yBootstrap() {
  useEffect(() => {
    apply(load());
  }, []);
}

export function AccessibilityPanel() {
  const [prefs, setPrefs] = useState<A11yPrefs>(DEFAULTS);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setPrefs(load());
  }, []);

  const update = (patch: Partial<A11yPrefs>) => {
    setPrefs((p) => {
      const next = { ...p, ...patch };
      apply(next);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const sizeIdx = ["sm", "md", "lg", "xl"].indexOf(prefs.fontScale);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          aria-label="Accessibility settings"
          className="inline-flex min-h-9 min-w-9 items-center justify-center rounded-xl border border-border bg-muted/40 p-2 transition-all hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Accessibility className="h-4 w-4" aria-hidden />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <Sparkles className="h-4 w-4 text-accent" aria-hidden />
            Accessibility
          </DialogTitle>
          <DialogDescription>
            Tune the experience to feel comfortable. Your settings save automatically.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 pt-2">
          <section aria-labelledby="font-size-label" className="space-y-2">
            <div className="flex items-center justify-between">
              <div id="font-size-label" className="flex items-center gap-2 text-sm font-semibold">
                <Type className="h-4 w-4 text-primary" aria-hidden /> Text size
              </div>
              <span className="text-xs uppercase tracking-wide text-muted-foreground">
                {prefs.fontScale}
              </span>
            </div>
            <Slider
              value={[sizeIdx]}
              min={0}
              max={3}
              step={1}
              onValueChange={(v) => {
                const map: FontScale[] = ["sm", "md", "lg", "xl"];
                update({ fontScale: map[v[0]] });
              }}
              aria-label="Text size"
            />
            <div className="flex justify-between text-[11px] text-muted-foreground">
              <span>Small</span>
              <span>Medium</span>
              <span>Large</span>
              <span>X-Large</span>
            </div>
          </section>

          <Row
            icon={MousePointer2}
            title="Reduce motion"
            desc="Calm down animations and transitions."
            checked={prefs.reducedMotion}
            onChange={(v) => update({ reducedMotion: v })}
          />
          <Row
            icon={Eye}
            title="High contrast"
            desc="Stronger borders and bolder text."
            checked={prefs.highContrast}
            onChange={(v) => update({ highContrast: v })}
          />
          <Row
            icon={BookOpen}
            title="Dyslexia-friendly text"
            desc="Wider spacing, easier-to-read font."
            checked={prefs.dyslexiaFont}
            onChange={(v) => update({ dyslexiaFont: v })}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Row({
  icon: Icon,
  title,
  desc,
  checked,
  onChange,
}: {
  icon: React.ComponentType<{ className?: string; "aria-hidden"?: boolean }>;
  title: string;
  desc: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-start justify-between gap-4 rounded-2xl border border-border/60 bg-muted/30 p-3 transition-colors hover:bg-muted/60">
      <div className="flex gap-3">
        <Icon className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
        <div>
          <div className="text-sm font-semibold">{title}</div>
          <div className="text-xs text-muted-foreground">{desc}</div>
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} aria-label={title} />
    </label>
  );
}
