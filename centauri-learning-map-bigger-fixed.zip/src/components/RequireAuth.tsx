import { ReactNode, useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useApp } from "@/lib/app-state";

export function RequireAuth({ children, requireOnboarding = false }: { children: ReactNode; requireOnboarding?: boolean }) {
  const { session, authReady, hasOnboarded } = useApp();
  const nav = useNavigate();

  useEffect(() => {
    if (!authReady) return;
    if (!session) {
      nav({ to: "/auth" });
    } else if (requireOnboarding && !hasOnboarded) {
      nav({ to: "/onboarding" });
    }
  }, [authReady, session, hasOnboarded, requireOnboarding, nav]);

  if (!authReady || !session || (requireOnboarding && !hasOnboarded)) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  return <>{children}</>;
}
