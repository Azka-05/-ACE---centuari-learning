import { motion } from "framer-motion";

interface StarMascotProps {
  message?: string;
  size?: number;
  className?: string;
}

const DEFAULT_MESSAGES = [
  "Small steps count.",
  "You're building momentum.",
  "Every expert started somewhere.",
  "You're closer than you think.",
  "Progress beats perfection.",
];

export function StarMascot({ message, size = 64, className = "" }: StarMascotProps) {
  const msg = message ?? DEFAULT_MESSAGES[Math.floor(Date.now() / 86400000) % DEFAULT_MESSAGES.length];
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <motion.div
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="relative shrink-0"
        style={{ width: size, height: size }}
        aria-hidden
      >
        {/* soft glow halo */}
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background:
              "radial-gradient(circle, color-mix(in oklch, var(--accent) 60%, transparent) 0%, transparent 70%)",
          }}
          animate={{ scale: [1, 1.15, 1], opacity: [0.6, 0.9, 0.6] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />
        <svg viewBox="0 0 64 64" width={size} height={size} className="relative">
          <defs>
            <radialGradient id="starBody" cx="50%" cy="40%" r="60%">
              <stop offset="0%" stopColor="oklch(0.96 0.05 75)" />
              <stop offset="60%" stopColor="oklch(0.82 0.10 50)" />
              <stop offset="100%" stopColor="oklch(0.65 0.12 30)" />
            </radialGradient>
          </defs>
          <path
            d="M32 6 L38.8 24.2 L58 26 L43.2 38.4 L48 57 L32 47 L16 57 L20.8 38.4 L6 26 L25.2 24.2 Z"
            fill="url(#starBody)"
            stroke="oklch(0.7 0.1 40)"
            strokeWidth="0.6"
            strokeLinejoin="round"
          />
          {/* eyes */}
          <circle cx="26" cy="30" r="1.6" fill="oklch(0.25 0.04 40)" />
          <circle cx="38" cy="30" r="1.6" fill="oklch(0.25 0.04 40)" />
          {/* smile */}
          <path d="M27 35 Q32 38 37 35" stroke="oklch(0.25 0.04 40)" strokeWidth="1.2" fill="none" strokeLinecap="round" />
        </svg>
      </motion.div>
      {msg && (
        <div className="text-sm italic text-muted-foreground">
          <span className="text-foreground/90">{msg}</span>
        </div>
      )}
    </div>
  );
}
