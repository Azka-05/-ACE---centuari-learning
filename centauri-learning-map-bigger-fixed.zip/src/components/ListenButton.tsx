import { Pause, Play, Square, Volume2 } from "lucide-react";
import { useState } from "react";
import { useSpeech } from "@/hooks/use-speech";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";

interface ListenButtonProps {
  text: string;
  label?: string;
  compact?: boolean;
  className?: string;
}

/**
 * Accessible TTS trigger. "Listen instead" CTA for any block of content.
 * Uses Web Speech API — no key, mobile-friendly.
 */
export function ListenButton({ text, label = "Listen", compact, className = "" }: ListenButtonProps) {
  const { supported, state, rate, setRate, speak, pause, resume, stop } = useSpeech();
  const [open, setOpen] = useState(false);

  if (!supported) return null;

  const playing = state === "playing";
  const paused = state === "paused";

  const onPrimary = () => {
    if (playing) pause();
    else if (paused) resume();
    else speak(text);
  };

  const Icon = playing ? Pause : paused ? Play : Volume2;
  const aria = playing ? "Pause reading" : paused ? "Resume reading" : `${label}: read this aloud`;

  return (
    <div className={`inline-flex items-center gap-1 rounded-full border border-border bg-card/70 p-1 shadow-sm ${className}`}>
      <button
        type="button"
        onClick={onPrimary}
        aria-label={aria}
        className="inline-flex min-h-9 items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary transition-all hover:bg-primary/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <Icon className="h-3.5 w-3.5" aria-hidden />
        {!compact && <span>{playing ? "Pause" : paused ? "Resume" : label}</span>}
      </button>
      {(playing || paused) && (
        <button
          type="button"
          onClick={stop}
          aria-label="Stop reading"
          className="inline-flex min-h-9 min-w-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-foreground"
        >
          <Square className="h-3.5 w-3.5" aria-hidden />
        </button>
      )}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            aria-label="Reading speed"
            className="rounded-full px-2 py-1 text-[11px] font-semibold text-muted-foreground transition-colors hover:text-foreground"
          >
            {rate.toFixed(2)}×
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-56" align="end">
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-medium">
              <span>Reading speed</span>
              <span className="text-muted-foreground">{rate.toFixed(2)}×</span>
            </div>
            <Slider
              value={[rate]}
              min={0.75}
              max={1.5}
              step={0.05}
              onValueChange={(v) => setRate(v[0])}
              aria-label="Reading speed"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>Slower</span>
              <span>Faster</span>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
