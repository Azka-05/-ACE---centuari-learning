import { AnimatePresence, motion } from "framer-motion";
import { Sparkles, Star } from "lucide-react";
import { levelFromXp } from "@/lib/gamification";
import { useApp } from "@/lib/app-state";

export function StarProgress({ size = 132, compact = false }: { size?: number; compact?: boolean }) {
  const { user } = useApp();
  const { level, pct, next } = levelFromXp(user.xp || 0);
  const fill = Math.round(pct * 100);
  const id = `star-fill-${size}`;

  return (
    <div className={`relative flex items-center ${compact ? "gap-3" : "gap-5"}`}>
      <div className="relative" style={{ width: size, height: size }} aria-label={`Level ${level}, ${user.xp || 0} XP`}>
        <svg viewBox="0 0 100 100" className="h-full w-full drop-shadow-[0_0_22px_color-mix(in_oklch,var(--accent)_55%,transparent)]">
          <defs>
            <linearGradient id={id} x1="0" x2="0" y1="1" y2="0">
              <stop offset={`${Math.max(0, fill - 1)}%`} stopColor="var(--accent)" />
              <stop offset={`${fill}%`} stopColor="var(--primary)" />
              <stop offset={`${fill + 0.5}%`} stopColor="color-mix(in oklch, var(--muted) 72%, transparent)" />
              <stop offset="100%" stopColor="color-mix(in oklch, var(--muted) 72%, transparent)" />
            </linearGradient>
            <filter id={`${id}-glow`} x="-40%" y="-40%" width="180%" height="180%">
              <feGaussianBlur stdDeviation="3.5" result="b" />
              <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>
          <motion.path
            d="M50 6 L62 36 L94 38 L69 58 L78 90 L50 72 L22 90 L31 58 L6 38 L38 36 Z"
            fill={`url(#${id})`}
            stroke="color-mix(in oklch, var(--accent) 70%, var(--primary))"
            strokeWidth="2"
            filter={`url(#${id}-glow)`}
            animate={{ scale: [1, 1.035, 1] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          />
        </svg>
        <motion.div className="absolute inset-0 flex items-center justify-center text-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-background/70 dark:text-white/70">Level</div>
            <div className="text-2xl font-black text-background dark:text-white">{level}</div>
          </div>
        </motion.div>
        <AnimatePresence>
          {user.xpToast && (
            <motion.div
              key={user.xpToast.id}
              initial={{ opacity: 0, y: 12, scale: 0.8 }}
              animate={{ opacity: 1, y: -22, scale: 1 }}
              exit={{ opacity: 0, y: -44 }}
              className="absolute left-1/2 top-2 -translate-x-1/2 rounded-full bg-accent px-3 py-1 text-xs font-black text-accent-foreground shadow-elegant"
            >
              +{user.xpToast.amount} XP
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <div className={compact ? "text-left" : "min-w-32 text-left"}>
        <div className="inline-flex items-center gap-1 rounded-full bg-accent/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-accent">
          <Sparkles className="h-3 w-3" /> ACE Star
        </div>
        <div className="mt-2 text-2xl font-black leading-none">{user.xp || 0} XP</div>
        <div className="mt-1 text-xs text-muted-foreground">{Math.max(0, next - (user.xp || 0))} XP to next level</div>
      </div>
    </div>
  );
}

export function LevelUpBurst({ show }: { show: boolean }) {
  return (
    <AnimatePresence>
      {show && <div className="pointer-events-none fixed inset-0 z-[80] flex items-center justify-center">
        {[...Array(14)].map((_, i) => (
          <motion.div key={i} initial={{ opacity: 1, scale: 0, x: 0, y: 0 }} animate={{ opacity: 0, scale: 1.2, x: Math.cos(i) * 160, y: Math.sin(i) * 140 }} exit={{ opacity: 0 }} transition={{ duration: 1.1 }}>
            <Star className="h-5 w-5 fill-accent text-accent" />
          </motion.div>
        ))}
      </div>}
    </AnimatePresence>
  );
}
