import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { Moon, Sun, Shield, Users, LogOut, UserCog, LogIn, Compass, Flame, Sparkles, Gift } from "lucide-react";
import { useApp } from "@/lib/app-state";
import { AccessibilityPanel } from "@/components/AccessibilityPanel";

const nav = [
  { to: "/access", label: "Access", icon: Shield },
  { to: "/connections", label: "Connect", icon: Users },
  { to: "/explore", label: "Explore", icon: Compass },
  { to: "/donor", label: "Donate", icon: Gift },
] as const;

export function Navbar() {
  const { theme, toggleTheme, user, session, signOut } = useApp();
  const loc = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate({ to: "/" });
  };

  return (
    <header className="sticky top-0 z-40 px-3 pt-3 sm:px-4 sm:pt-4">
      <div className="glass mx-auto flex max-w-6xl items-center justify-between rounded-2xl px-3 py-3 shadow-elegant sm:px-4">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <Sparkles className="h-5 w-5 text-accent" />
          <span className="text-gradient">Centauri Learning</span>
        </Link>
        {session && (
          <nav className="hidden items-center gap-1 md:flex">
            {nav.map((n) => {
              const active = loc.pathname.startsWith(n.to);
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={`rounded-xl px-3 py-2 text-sm font-medium transition-all ${
                    active
                      ? "bg-primary text-primary-foreground"
                      : "text-foreground/80 hover:bg-muted hover:text-foreground"
                  }`}
                >
                  <span className="inline-flex items-center gap-1.5"><n.icon className="h-4 w-4" />{n.label}</span>
                </Link>
              );
            })}
          </nav>
        )}
        <div className="flex items-center gap-2">
          {session && (
            <span className="hidden items-center gap-1 rounded-full bg-primary/15 px-2.5 py-1 text-xs font-semibold text-primary sm:inline-flex">
              <Flame className="h-3 w-3" /> {user.streak || 0} · {user.xp || 0} XP
            </span>
          )}
          <AccessibilityPanel />
          <button
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="rounded-xl border border-border bg-muted/40 p-2 transition-all hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring min-h-9 min-w-9"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          {session ? (
            <>
              <Link to="/account" aria-label="Account"
                className="rounded-xl border border-border bg-muted/40 p-2 transition-all hover:bg-muted">
                <UserCog className="h-4 w-4" />
              </Link>
              <button onClick={handleLogout} aria-label="Log out"
                className="rounded-xl border border-border bg-muted/40 p-2 transition-all hover:bg-muted">
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <Link to="/auth"
              className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90">
              <LogIn className="h-4 w-4" /> Sign in
            </Link>
          )}
        </div>
      </div>
      {session && (
        <nav className="fixed inset-x-3 bottom-3 z-50 flex items-center justify-around rounded-3xl border border-border bg-card/92 px-2 py-2 shadow-elegant backdrop-blur-xl md:hidden">
          {nav.map((n) => {
            const active = loc.pathname.startsWith(n.to);
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`flex min-h-12 flex-1 flex-col items-center justify-center rounded-2xl px-2 py-1.5 text-[11px] font-medium ${
                  active ? "bg-primary text-primary-foreground" : "text-foreground/70"
                }`}
              >
                <n.icon className="h-4 w-4" />
                {n.label}
              </Link>
            );
          })}
        </nav>
      )}
    </header>
  );
}
