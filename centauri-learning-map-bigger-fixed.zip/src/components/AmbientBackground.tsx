import { motion } from "framer-motion";

/**
 * Global ambience layer: warm, inclusive and subtle.
 * This avoids the harsh empty AI-template background while keeping the constellation identity.
 */
export function AmbientBackground() {
  const stars = Array.from({ length: 34 });

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden a11y-hide-adhd">
      <div className="absolute inset-0 bg-hero" />

      <motion.div
        className="absolute -left-40 -top-36 h-[42rem] w-[42rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, color-mix(in oklch, var(--accent) 22%, transparent), transparent 70%)" }}
        animate={{ x: [0, 42, 0], y: [0, 28, 0], scale: [1, 1.05, 1] }}
        transition={{ duration: 26, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute -right-44 top-1/4 h-[38rem] w-[38rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, color-mix(in oklch, var(--primary) 20%, transparent), transparent 72%)" }}
        animate={{ x: [0, -36, 0], y: [0, -24, 0], scale: [1, 1.08, 1] }}
        transition={{ duration: 30, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-[-12rem] left-1/4 h-[34rem] w-[34rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, color-mix(in oklch, var(--aurora-lilac, #B7A6E0) 16%, transparent), transparent 72%)" }}
        animate={{ x: [0, 32, 0], y: [0, -36, 0], scale: [1.03, 1, 1.03] }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
      />

      <svg className="absolute inset-0 h-full w-full opacity-[0.18] dark:opacity-[0.26]" preserveAspectRatio="none">
        <defs>
          <linearGradient id="ambient-line" x1="0" x2="1" y1="0" y2="1">
            <stop stopColor="var(--aurora-peach)" stopOpacity="0.55" />
            <stop offset="1" stopColor="var(--aurora-lilac)" stopOpacity="0.2" />
          </linearGradient>
        </defs>
        <path d="M80 160 C240 70 380 250 560 140 S880 110 1060 240" fill="none" stroke="url(#ambient-line)" strokeWidth="1" />
        <path d="M120 540 C320 380 500 620 760 470 S1020 420 1220 600" fill="none" stroke="url(#ambient-line)" strokeWidth="1" />
      </svg>

      {stars.map((_, i) => (
        <motion.span
          key={i}
          className="absolute rounded-full bg-foreground/30 dark:bg-white/45"
          style={{
            width: 1.5 + (i % 3),
            height: 1.5 + (i % 3),
            left: `${(i * 47) % 100}%`,
            top: `${(i * 31) % 100}%`,
            boxShadow: "0 0 10px color-mix(in oklch, var(--accent) 55%, transparent)",
          }}
          animate={{ opacity: [0.16, 0.72, 0.16], y: [0, -12, 0] }}
          transition={{ duration: 7 + (i % 7), repeat: Infinity, delay: i * 0.18, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
}
