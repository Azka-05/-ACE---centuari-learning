// Career-personalised dual learning trees.
// Each career generates exactly TWO branching trees (left + right) that
// converge on the same career goal.

export type NodeKind = "lesson" | "challenge" | "quiz" | "project" | "milestone";

export interface QuizQuestion {
  q: string;
  options: string[];
  correct: number;
  why: string;
}

export interface CareerNode {
  id: string;
  title: string;
  xp: number;
  kind: NodeKind;
  blurb: string;
  // Rich educational content (rendered as paragraphs)
  content: string[];
  // Real practical exercise
  exercise: string;
  // 2-3 quiz questions; must pass to progress
  quiz: QuizQuestion[];
  keyTakeaways?: string[];
  deliverable?: {
    type: "url" | "file" | "video";
    prompt: string;
    examples: string[];
    acceptedFormats?: string[];
  };
  // optional branching child node ids — for organic tree growth
  children?: string[];
}

export interface CareerTree {
  id: string;
  title: string;
  subtitle: string;
  hueA: string; // start glow color
  hueB: string; // end glow color
  nodes: CareerNode[];
}

export interface CareerPath {
  id: string;
  name: string;
  tagline: string;
  emoji: string;
  trees: [CareerTree, CareerTree];
}

// --- Helpers to keep node definitions short ---
const q = (qq: string, options: string[], correct: number, why: string): QuizQuestion =>
  ({ q: qq, options, correct, why });

// =========================================================
// CONTENT CREATOR
// =========================================================
const CONTENT_CREATOR: CareerPath = {
  id: "content-creator",
  name: "Content Creator",
  tagline: "Tell stories that move audiences across platforms.",
  emoji: "🎬",
  trees: [
    {
      id: "cc-left", title: "Marketing & Branding",
      subtitle: "Build a voice people remember.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "cc-l1", title: "What is a Brand?", xp: 30, kind: "lesson",
          blurb: "A brand is a feeling, not a logo.",
          content: [
            "A brand is the gut-feeling someone gets when they hear your name. Logos, colours and fonts are just signals — the brand lives in the audience's head.",
            "Strong creator brands answer three questions in under five seconds: Who are you for? What do you stand for? What can people expect every time?",
            "Example: MKBHD = 'high-trust tech reviews, clean visuals, calm delivery.' That clarity is why people subscribe.",
          ],
          exercise: "Write your own brand in one sentence using the template: 'I help [audience] [transformation] through [format].'",
          quiz: [
            q("What best defines a brand?",
              ["Your logo", "The feeling people associate with you", "Your follower count"], 1,
              "Visuals are signals; the brand itself is the perception."),
            q("Which is the strongest brand promise?",
              ["I post sometimes about random stuff", "Weekly 60-second productivity tips for students", "Vlogs and memes"], 1,
              "Specific audience + format + value beats vague topics."),
          ],
        },
        {
          id: "cc-l2", title: "Audience Personas", xp: 40, kind: "lesson",
          blurb: "Write for one person, reach thousands.",
          content: [
            "A persona is a sketch of one real-feeling viewer. Give them a name, age, a problem they wrestle with, and a moment they'd watch your content (lunch break? falling asleep?).",
            "When you write for 'everyone' the post sounds like nobody. When you write for 'Maya, 19, learning to edit on her phone in bed,' the words sharpen.",
          ],
          exercise: "Write a 4-line persona for your ideal viewer including their name, age, struggle, and when they scroll.",
          quiz: [
            q("Why are personas useful?",
              ["They guarantee virality", "They make your writing specific", "They replace analytics"], 1,
              "Specificity is what makes content feel made-for-me."),
          ],
        },
        {
          id: "cc-l3", title: "Hooks That Hold", xp: 50, kind: "challenge",
          blurb: "The first 3 seconds decide everything.",
          content: [
            "A hook is a promise: 'stay and you'll get X'. On TikTok and Reels, the algorithm watches whether people swipe away in the first 1.5–3 seconds.",
            "Strong hook patterns: contrarian ('Stop doing X'), curiosity gap ('Nobody told me Y until I…'), pattern-break (a visual that doesn't match the audio), stakes ('I almost lost my job because of this').",
          ],
          exercise: "Take a weak hook ('Today I want to talk about productivity') and rewrite it three different ways using contrarian, curiosity, and stakes patterns.",
          quiz: [
            q("Which is the strongest hook?",
              ["Hey guys, welcome back to my channel", "I tried waking up at 5am for 30 days — here's what broke me", "Today's video is about mornings"], 1,
              "Stakes + specificity + curiosity = retention."),
            q("How long do you have to earn the swipe?",
              ["10 seconds", "1.5–3 seconds", "30 seconds"], 1,
              "Most platforms judge retention in the first ~3 seconds."),
          ],
        },
        {
          id: "cc-l4", title: "Visual Identity Project", xp: 90, kind: "project",
          blurb: "Design a mini brand kit.",
          deliverable: { type: "url", prompt: "Share a link to your mini brand kit or thumbnail mockups.", examples: ["Figma brand board link", "Canva design share link", "Google Drive folder with thumbnails"] },
          content: [
            "A brand kit locks in: 1 primary font, 1 supporting font, 3 brand colours (background, text, accent), and a recognisable thumbnail style.",
            "Consistency compounds. People recognise creators by thumbnail patterns before they read a single word.",
          ],
          exercise: "Pick 2 fonts (Google Fonts is fine), 3 colours, and sketch 3 thumbnails that all clearly belong to the same channel.",
          quiz: [
            q("What makes thumbnails feel like one brand?",
              ["Using a different style each time", "Repeating font, colour and layout patterns", "Always using your face"], 1,
              "Repetition is what builds visual recognition."),
          ],
        },
      ],
    },
    {
      id: "cc-right", title: "Audience Engagement & Strategy",
      subtitle: "Turn views into a community.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "cc-r1", title: "How Algorithms Work", xp: 35, kind: "lesson",
          blurb: "Engagement signals beat upload time.",
          content: [
            "Recommendation algorithms (TikTok, YouTube Shorts, Reels) test every post on a small audience first. They watch: average watch time, completion rate, re-watches, shares, and saves.",
            "If your post performs above average for that mini-audience, it gets shown to a bigger one. Repeat. This is why one post can hit 1M while another from the same account does 200 views.",
            "What it does NOT care about: how hard you worked, follower count alone, or how good you feel about the post.",
          ],
          exercise: "Open one of your favourite creators' last 10 posts. Note which got 10x more views than their average. What pattern do you see?",
          quiz: [
            q("What signal matters most for short-form?",
              ["Number of followers", "Watch-time and completion rate", "Posting at midnight"], 1,
              "The algorithm cares about how long people stay."),
            q("Why do some posts blow up while others flop on the same account?",
              ["The algorithm is broken", "Each post is tested on a small audience first", "Luck only"], 1,
              "It's a per-post test, not an account-wide score."),
          ],
        },
        {
          id: "cc-r2", title: "Watch Time & Retention", xp: 45, kind: "lesson",
          blurb: "Edit ruthlessly. Earn every second.",
          content: [
            "Retention graphs show exactly where viewers leave. The drop usually happens at: a slow intro, a long transition, or a moment that doesn't pay off the hook.",
            "Rule of thumb: if a sentence doesn't add information or emotion, cut it. Add a visual change (zoom, text on screen, b-roll) every 2–4 seconds in short-form.",
          ],
          exercise: "Re-edit any 60-second video of yours (or a friend's): remove every 'um', every dead 0.5s pause, and add one text overlay.",
          quiz: [
            q("What's the best fix for a 30% drop at 4 seconds in?",
              ["Add a longer intro", "Sharpen the hook and cut the first sentence", "Post at a different time"], 1,
              "Early drops mean the hook didn't deliver."),
          ],
        },
        {
          id: "cc-r3", title: "Content Pillars", xp: 40, kind: "lesson",
          blurb: "3 buckets beat 30 random ideas.",
          content: [
            "Pillars are 3–4 themes you'll always post about. They make planning easier and signal to the algorithm what your account is 'about', so it shows you to the right audience.",
            "Good pillar mix: 1 educational, 1 personal/story, 1 entertaining. Rotate them weekly.",
          ],
          exercise: "Write down your 3 pillars and brainstorm 5 post ideas under each.",
          quiz: [
            q("Why do pillars help?",
              ["They limit you creatively", "They focus the algorithm and your planning", "They guarantee growth"], 1,
              "Focus helps both you and the algorithm."),
          ],
        },
        {
          id: "cc-r4", title: "Campaign Project", xp: 100, kind: "project",
          blurb: "Plan a 7-day content campaign.",
          deliverable: { type: "url", prompt: "Share a 7-day campaign plan link.", examples: ["Notion campaign plan", "Google Doc content calendar", "Canva campaign board"] },
          content: [
            "A campaign is a series of posts that build on each other to drive one specific action (subscribe, sign up, watch a longer video).",
            "Each post should be standalone (so a new viewer gets it) but reward people who saw the previous ones.",
          ],
          exercise: "Plan 7 posts around one goal. For each: hook, format, pillar, and the call-to-action.",
          quiz: [
            q("Best campaign structure?",
              ["Identical post every day", "7 posts building toward one CTA, each working standalone", "Random posts whenever"], 1,
              "Coherence + accessibility for new viewers."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// DATA ENGINEER
// =========================================================
const DATA_ENGINEER: CareerPath = {
  id: "data-engineer",
  name: "Data Engineer",
  tagline: "Build the pipelines that power AI and analytics.",
  emoji: "🛠️",
  trees: [
    {
      id: "de-left", title: "AI & ML Foundations",
      subtitle: "Understand what models actually do.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "de-l1", title: "What is Machine Learning?", xp: 35, kind: "lesson",
          blurb: "Models learn patterns from examples.",
          content: [
            "Traditional code: you write rules. ML: you show examples, the computer figures out the rules.",
            "Three main flavours: supervised (labelled examples → predictions), unsupervised (find groupings), and reinforcement (learn by trial and reward).",
            "A model is just a mathematical function with tunable numbers (weights). Training = adjust the weights so predictions match reality on training data.",
          ],
          exercise: "Pick 3 features of your favourite app (Spotify, TikTok, Gmail) and identify which use ML vs hard-coded rules.",
          quiz: [
            q("What's the core difference vs traditional programming?",
              ["ML uses Python", "You provide examples instead of rules", "ML is always faster"], 1,
              "Examples in → rules out, the opposite of normal code."),
            q("Spam filter that learns from your 'mark as spam' clicks is which type?",
              ["Unsupervised", "Supervised", "Reinforcement"], 1,
              "Labelled examples (spam vs not) = supervised."),
          ],
        },
        {
          id: "de-l2", title: "Data Quality", xp: 40, kind: "lesson",
          blurb: "Garbage in, garbage out.",
          content: [
            "Most ML failures are data problems, not model problems. A perfect model on bad data gives confident, wrong answers.",
            "Common issues: missing values, duplicates, inconsistent units (kg vs lbs), bias in who's represented, and leakage (the training data secretly contains the answer).",
          ],
          exercise: "Imagine a dataset of UK student grades. List 3 ways the data could be biased and how you'd fix each.",
          quiz: [
            q("Why is data leakage bad?",
              ["It crashes the model", "The model looks great in tests but fails in real use", "It's a security issue"], 1,
              "Leakage gives the model the answer during training."),
          ],
        },
        {
          id: "de-l3", title: "Train a Tiny Model", xp: 70, kind: "challenge",
          blurb: "Use a no-code tool to classify.",
          content: [
            "Teachable Machine (teachablemachine.withgoogle.com) lets you train an image classifier in your browser with no code.",
            "You'll see firsthand: more varied examples = better model. 3 photos of you smiling won't generalise to other people.",
          ],
          exercise: "Open Teachable Machine and train a classifier with 2 classes (e.g. cup vs phone). Test it with new angles and lighting.",
          quiz: [
            q("Your model is 100% on training, 50% on new data. What's likely?",
              ["Perfect model", "Overfitting — memorised instead of learned", "Need more layers"], 1,
              "Memorising training data is called overfitting."),
          ],
        },
      ],
    },
    {
      id: "de-right", title: "Backend & Data Systems",
      subtitle: "Move data reliably at scale.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "de-r1", title: "Databases 101", xp: 35, kind: "lesson",
          blurb: "Tables, rows, relationships.",
          content: [
            "A relational database stores data in tables. Each row is one record, each column is one field. Tables relate via shared IDs (foreign keys).",
            "Why relational? It enforces consistency. If you delete a user, the database can stop you from leaving 'orphan' orders pointing at nothing.",
            "SQL is the language to query it: SELECT name FROM users WHERE country = 'UK';",
          ],
          exercise: "Sketch tables for a simple library app: books, members, loans. What columns? What are the foreign keys?",
          quiz: [
            q("What's a foreign key?",
              ["A password", "A column pointing to another table's row", "An import statement"], 1,
              "FK = the link between tables."),
          ],
        },
        {
          id: "de-r2", title: "APIs Explained", xp: 40, kind: "lesson",
          blurb: "How apps talk to each other.",
          content: [
            "An API is a menu: 'here's what I can do, here's how to ask'. You send a request (usually HTTPS), you get a response (usually JSON).",
            "REST is the most common style: GET /users/42 fetches user 42, POST /users creates a new one.",
            "Auth (API keys, OAuth) decides who's allowed to ask what.",
          ],
          exercise: "Open the GitHub API docs and find the endpoint to list a user's public repos. Note the URL pattern.",
          quiz: [
            q("What does GET /posts/5 usually do?",
              ["Delete post 5", "Fetch post 5", "Create post 5"], 1,
              "GET = read; POST = create; DELETE = remove."),
          ],
        },
        {
          id: "de-r3", title: "Data Pipeline Project", xp: 100, kind: "project",
          blurb: "Design an end-to-end flow.",
          content: [
            "A pipeline: source → ingest → clean → store → serve. Each stage can fail; good pipelines log everything and retry safely (idempotent).",
            "Example: Twitter posts → fetch every 10 min → strip emojis → store in a table → expose via an API for an analytics dashboard.",
          ],
          exercise: "Draw a 5-step pipeline for tracking your daily steps from phone → dashboard. Mark where it could fail and how you'd recover.",
          quiz: [
            q("What does 'idempotent' mean for a pipeline step?",
              ["It runs only once", "Running it twice gives the same result as once", "It's encrypted"], 1,
              "Idempotency = safe to retry."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// CYBERSECURITY ANALYST
// =========================================================
const CYBER_ANALYST: CareerPath = {
  id: "cyber-analyst",
  name: "Cybersecurity Analyst",
  tagline: "Defend systems and the people who use them.",
  emoji: "🛡️",
  trees: [
    {
      id: "cy-left", title: "Network Security",
      subtitle: "Lock down the wires.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "cy-l1", title: "How the Internet Works", xp: 35, kind: "lesson",
          blurb: "Packets, IPs, DNS.",
          content: [
            "When you visit a site, your device asks a DNS server to translate the name (google.com) to an IP address (a phone number for servers).",
            "Then your browser opens a connection and exchanges small chunks called packets. Each packet has a 'from' and 'to' address — anyone sitting on the network in between can see metadata.",
            "HTTPS encrypts the contents but not WHO is talking to whom.",
          ],
          exercise: "Open a terminal and run 'nslookup github.com'. Note the IP returned.",
          quiz: [
            q("What does DNS do?",
              ["Encrypts your traffic", "Translates names to IP addresses", "Blocks malware"], 1,
              "Think phonebook: name → number."),
            q("HTTPS hides…",
              ["Which sites you visit", "The contents of your requests", "Your IP"], 1,
              "Contents are encrypted; the destination IP is still visible."),
          ],
        },
        {
          id: "cy-l2", title: "Firewalls & Filtering", xp: 40, kind: "lesson",
          blurb: "Allow what's needed, block the rest.",
          content: [
            "A firewall is a gatekeeper sitting between networks. Default-deny means: block everything, then allow specific things — far safer than allow-everything-and-block-bad.",
            "Rules typically check: source IP, destination port, and protocol.",
          ],
          exercise: "Sketch a 3-rule firewall policy for a home server: only SSH from your IP, HTTPS for everyone, block the rest.",
          quiz: [
            q("Which policy is safer by default?",
              ["Allow all, block known bad", "Block all, allow known good", "Allow weekdays only"], 1,
              "Default-deny is the industry gold standard."),
          ],
        },
      ],
    },
    {
      id: "cy-right", title: "Threat Detection & Ethical Hacking",
      subtitle: "Think like an attacker, defend like a pro.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "cy-r1", title: "Phishing Mastery", xp: 35, kind: "challenge",
          blurb: "Spot the lure.",
          content: [
            "Phishing exploits trust, not tech. Signals: urgency ('account closes in 24h'), mismatched sender domains (suppor t@app1e.com), generic greetings, suspicious links (hover before clicking).",
            "Sophisticated phishing copies real brand emails pixel-for-pixel. The reliable check is the actual URL, not how it looks.",
          ],
          exercise: "Open your inbox. Find one email and check: real sender domain? hover-over URL matches the brand?",
          quiz: [
            q("The most reliable phishing tell is…",
              ["Bad grammar", "The actual sender domain and link URL", "An attached PDF"], 1,
              "Visuals can be perfect; URLs reveal the truth."),
            q("'Your account expires in 1 hour, click here' is using…",
              ["Authority", "Urgency", "Reciprocity"], 1,
              "Urgency rushes people past their judgement."),
          ],
        },
        {
          id: "cy-r2", title: "Ethical Hacking Mindset", xp: 60, kind: "lesson",
          blurb: "Permission is the line.",
          content: [
            "Ethical hackers (pen-testers) are paid to break systems so attackers can't. The difference between hero and criminal is one document: written permission (scope of engagement).",
            "Always-illegal: testing systems you don't own without consent, even 'just looking'.",
            "Start legally: TryHackMe, HackTheBox, PortSwigger Web Security Academy — purpose-built playgrounds.",
          ],
          exercise: "Sign up for TryHackMe's free path and complete the 'Intro to Cyber Security' room.",
          quiz: [
            q("What separates a pen-tester from a criminal?",
              ["Skill level", "Written permission and scope", "The tools used"], 1,
              "Consent is the legal and ethical line."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// UX DESIGNER
// =========================================================
const UX_DESIGNER: CareerPath = {
  id: "ux-designer",
  name: "UX Designer",
  tagline: "Design products that respect every user.",
  emoji: "🎨",
  trees: [
    {
      id: "ux-left", title: "Visual Design & Accessibility",
      subtitle: "Beautiful is also usable.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "ux-l1", title: "Colour & Contrast", xp: 35, kind: "lesson",
          blurb: "Readable for everyone.",
          content: [
            "WCAG (the web accessibility standard) requires contrast ratios of at least 4.5:1 for body text and 3:1 for large text.",
            "Low-contrast greys look modern but exclude users with low vision, in bright sunlight, or on cheap screens.",
            "Tools: WebAIM Contrast Checker. Always test light AND dark mode.",
          ],
          exercise: "Open a site you visit daily. Paste its body text and background colour into WebAIM's checker. Does it pass AA?",
          quiz: [
            q("Minimum contrast ratio for body text (AA)?",
              ["3:1", "4.5:1", "7:1"], 1,
              "AA: 4.5:1 for normal text, 3:1 for large."),
            q("Why is low-contrast grey-on-grey a problem?",
              ["It's ugly", "It excludes low-vision users and outdoor readers", "It's slower to load"], 1,
              "Accessibility isn't optional polish."),
          ],
        },
        {
          id: "ux-l2", title: "Typography Rhythm", xp: 35, kind: "lesson",
          blurb: "Type creates emotion.",
          content: [
            "Establish a type scale (e.g. 12, 14, 16, 20, 24, 32, 48). Stick to it — too many sizes feels chaotic.",
            "Line-height ~1.5 for body. Line-length 50–75 characters. Both reduce reading fatigue.",
          ],
          exercise: "Audit any landing page. Count how many distinct font sizes it uses. More than 6? It probably feels noisy.",
          quiz: [
            q("Ideal line length for comfortable reading?",
              ["20–30 characters", "50–75 characters", "100–120 characters"], 1,
              "Eye movement gets tiring beyond ~75."),
          ],
        },
        {
          id: "ux-l3", title: "Accessibility Redesign", xp: 90, kind: "project",
          blurb: "Fix a real inaccessible UI.",
          content: [
            "Find a UI in the wild that has poor contrast, tiny tap targets, or missing labels. Redesign one screen with: AA contrast, 44px minimum tap targets, visible focus states, and ARIA labels for icons.",
          ],
          exercise: "Pick a screenshot of an app or site. Mark every accessibility issue, then redesign one screen in Figma or on paper.",
          quiz: [
            q("Minimum tap target size on mobile?",
              ["24px", "32px", "44px"], 2,
              "Apple/Google both recommend ~44px."),
          ],
        },
      ],
    },
    {
      id: "ux-right", title: "User Research & UX Systems",
      subtitle: "Decisions backed by evidence.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "ux-r1", title: "User Interviews", xp: 35, kind: "lesson",
          blurb: "Ask about behaviour, not opinions.",
          content: [
            "'Would you use this?' is a useless question — people are polite. Instead ask about the last time they did something: 'Tell me about the last time you booked a doctor's appointment. Walk me through it.'",
            "Stories reveal real friction. Opinions reveal flattery.",
          ],
          exercise: "Pick a product you use. Interview a friend with: 'Tell me about the last time you used [X]. What was annoying?' Listen for 5 minutes without interrupting.",
          quiz: [
            q("Which question gets the most useful data?",
              ["Would you use this feature?", "Walk me through the last time you did X", "Do you like our app?"], 1,
              "Behaviour over opinion."),
          ],
        },
        {
          id: "ux-r2", title: "Usability Testing", xp: 50, kind: "challenge",
          blurb: "Watch people use it.",
          content: [
            "5 users uncover ~80% of usability issues (Nielsen). Sit a person in front of your design, give them a task ('try to book a table for two'), and watch silently. The pauses and frowns are the data.",
            "Don't explain — if they're confused, your design needs to be clearer, not your voice.",
          ],
          exercise: "Run a 10-minute usability test of any app on a friend. Note 3 things they hesitated on.",
          quiz: [
            q("Roughly how many test users to find most usability issues?",
              ["20+", "5", "1"], 1,
              "Nielsen's classic finding: 5 is enough for most studies."),
          ],
        },
        {
          id: "ux-r3", title: "Design System Project", xp: 90, kind: "project",
          blurb: "Build a reusable component library.",
          content: [
            "A design system is a single source of truth: components (buttons, inputs), tokens (colours, spacing), and rules.",
            "It speeds teams up because nobody re-decides what a button looks like every Tuesday.",
          ],
          exercise: "In Figma, create a mini design system: 3 button states, 2 input states, a colour palette and a spacing scale.",
          quiz: [
            q("Main benefit of a design system?",
              ["Looks cooler", "Consistency + speed across a team", "Replaces designers"], 1,
              "It's a force multiplier, not a replacement."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// SOFTWARE DEVELOPER
// =========================================================
const SOFTWARE_DEV: CareerPath = {
  id: "software-dev",
  name: "Software Developer",
  tagline: "Build the apps people rely on every day.",
  emoji: "💻",
  trees: [
    {
      id: "sd-left", title: "Frontend Foundations",
      subtitle: "Build interfaces people love.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "sd-l1", title: "HTML Structure", xp: 30, kind: "lesson",
          blurb: "Semantics make the web work.",
          content: [
            "HTML describes structure with tags: <header>, <main>, <nav>, <article>, <button>. Using the right tag isn't just tidy — screen readers, search engines and keyboard users all depend on it.",
            "<div> is fine for layout but means nothing semantically. <button> can be focused, clicked with Enter, and announced as 'button' to screen readers. <div onClick> can't.",
          ],
          exercise: "Open any site, right-click → Inspect. Find a <div> that should have been a <button>. (You'll find one in under a minute.)",
          quiz: [
            q("Why prefer <button> over <div onClick>?",
              ["Less code", "Keyboard + screen reader accessible by default", "Faster"], 1,
              "Semantics give you accessibility for free."),
          ],
        },
        {
          id: "sd-l2", title: "CSS Layout", xp: 40, kind: "lesson",
          blurb: "Flexbox + Grid solve 95%.",
          content: [
            "Flexbox: one-dimensional layouts (a row or a column). Grid: two-dimensional (rows AND columns at once).",
            "Stop using floats. Stop using tables for layout. Flex and Grid handle responsive layouts cleanly.",
          ],
          exercise: "Build a 3-column responsive card grid with CSS Grid in 10 lines of CSS.",
          quiz: [
            q("Which is best for a 2D layout?",
              ["Flexbox", "CSS Grid", "Floats"], 1,
              "Grid handles rows+columns; Flex is 1D."),
          ],
        },
        {
          id: "sd-l3", title: "JavaScript Logic", xp: 50, kind: "challenge",
          blurb: "Make pages respond.",
          content: [
            "JS adds behaviour: react to clicks, fetch data, update the page. Start with: variables (let/const), functions, arrays, objects, and event listeners.",
            "Modern JS: arrow functions, template literals, async/await for asynchronous work like fetching from an API.",
          ],
          exercise: "Write a 10-line script that adds a button to the page and counts clicks.",
          quiz: [
            q("What does 'const' mean?",
              ["The value never changes", "The reference can't be reassigned", "It's faster"], 1,
              "Objects/arrays can still mutate; only the binding is fixed."),
          ],
        },
        {
          id: "sd-l4", title: "React App Project", xp: 100, kind: "project",
          blurb: "Build a real interactive app.",
          content: [
            "React: write components (functions that return UI), use state (useState) for things that change, props to pass data down.",
            "Start small: a todo app, a search filter, a colour picker. Ship it on Vercel or Netlify.",
          ],
          exercise: "Build and deploy a single-page React app of your choosing. Share the URL.",
          quiz: [
            q("What's useState for?",
              ["Styling", "Tracking values that change over time in a component", "Routing"], 1,
              "State = data that drives re-rendering."),
          ],
        },
      ],
    },
    {
      id: "sd-right", title: "Backend & APIs",
      subtitle: "Power apps from the server side.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "sd-r1", title: "Servers & Requests", xp: 35, kind: "lesson",
          blurb: "Request → process → respond.",
          content: [
            "A server is just a program waiting for HTTP requests. It reads the URL, the method (GET/POST/etc), the body, then sends a response.",
            "Node.js + Express, Python + FastAPI, Go — all do this same job in different languages.",
          ],
          exercise: "Sketch the request/response cycle for clicking 'like' on a post. What goes to the server? What comes back?",
          quiz: [
            q("What's a server in plain terms?",
              ["A physical box", "A program waiting for and responding to requests", "A database"], 1,
              "It's a program, not necessarily a special machine."),
          ],
        },
        {
          id: "sd-r2", title: "Auth & Sessions", xp: 50, kind: "lesson",
          blurb: "Who is this user?",
          content: [
            "Authentication: proving who you are (email+password, OAuth via Google). Authorisation: what you're allowed to do.",
            "Modern apps use tokens (JWT) or session cookies. Never store passwords in plaintext — always hash with bcrypt/argon2.",
          ],
          exercise: "Read about bcrypt. Why does it intentionally run slowly?",
          quiz: [
            q("Why hash passwords (vs encrypt)?",
              ["Hashes are one-way; even the company can't read them", "Hashes are faster", "Hashes use less storage"], 0,
              "One-way protects users even if the DB leaks."),
          ],
        },
        {
          id: "sd-r3", title: "Full-Stack Project", xp: 110, kind: "project",
          blurb: "Connect frontend, API, database.",
          content: [
            "End-to-end: React frontend → REST API → Postgres database. Add auth, deploy on a platform like Vercel + Supabase.",
            "This is the project that gets you junior dev interviews.",
          ],
          exercise: "Build any CRUD app (notes, tasks, recipes) with login. Deploy it. Add the link to your CV.",
          quiz: [
            q("What does CRUD stand for?",
              ["Create, Read, Update, Delete", "Code, Run, Update, Debug", "Compile, Render, Use, Deploy"], 0,
              "The four operations every basic app does."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// AI ENGINEER
// =========================================================
const AI_ENGINEER: CareerPath = {
  id: "ai-engineer",
  name: "AI Engineer",
  tagline: "Build products powered by modern AI models.",
  emoji: "🤖",
  trees: [
    {
      id: "ai-left", title: "Prompting & LLM Basics",
      subtitle: "Speak the model's language.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "ai-l1", title: "How LLMs Work", xp: 40, kind: "lesson",
          blurb: "Pattern matching at massive scale.",
          content: [
            "Large Language Models predict the next token (chunk of text) based on everything they've read. They don't 'know' facts the way a database does — they compress patterns from training data.",
            "This is why they hallucinate: when patterns don't strongly predict the right answer, they confidently produce plausible-sounding nonsense.",
            "Mitigations: retrieval (give the model the right document), grounding (cite sources), and verification (ask another model to check).",
          ],
          exercise: "Ask ChatGPT a niche question about your school or hometown. Notice where it confidently invents details.",
          quiz: [
            q("Why do LLMs hallucinate?",
              ["Bug in the code", "They predict plausible patterns, not look up facts", "Internet is wrong"], 1,
              "It's a property of how they work, not a bug."),
          ],
        },
        {
          id: "ai-l2", title: "Prompt Engineering", xp: 45, kind: "challenge",
          blurb: "Specific prompts beat clever ones.",
          content: [
            "Effective prompts: give role ('You are a senior editor…'), give context (the actual document), give task ('rewrite for clarity, keep under 200 words'), and give format ('respond as a bullet list').",
            "Few-shot: show 2-3 examples of input → desired output. Models pattern-match brilliantly when given examples.",
          ],
          exercise: "Take a vague prompt ('write a poem') and rewrite it with role + context + constraints + format.",
          quiz: [
            q("Which prompt is likely strongest?",
              ["Write something good about cats", "Act as a children's book editor. Write a 6-line rhyming poem about a sleepy cat. End on a peaceful image.", "Cats?"], 1,
              "Role + format + constraints beat vague."),
          ],
        },
      ],
    },
    {
      id: "ai-right", title: "Building AI Apps",
      subtitle: "Ship products that use AI safely.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "ai-r1", title: "Calling AI APIs", xp: 45, kind: "lesson",
          blurb: "From prompt to product.",
          content: [
            "Most AI features are HTTP calls to a model API (OpenAI, Anthropic, Google). You send messages, you get a response. The hard part is product design around it: streaming, error handling, cost limits, content moderation.",
          ],
          exercise: "Read the OpenAI chat completions docs. Identify the 3 required fields in a basic call.",
          quiz: [
            q("What's the biggest risk when shipping AI features?",
              ["The model is too smart", "Hallucinations + cost + safety in production", "Servers melting"], 1,
              "Production AI is mostly about guardrails."),
          ],
        },
        {
          id: "ai-r2", title: "RAG Pipeline Project", xp: 100, kind: "project",
          blurb: "Ground an LLM in your own data.",
          content: [
            "Retrieval Augmented Generation: store your docs as embeddings (vectors), search the most relevant chunks for each user question, stuff them into the prompt. Result: answers grounded in your data, not Wikipedia.",
          ],
          exercise: "Build a 'chat with my PDF' demo using any embedding API + a vector store (Supabase, Pinecone).",
          quiz: [
            q("Why does RAG reduce hallucinations?",
              ["More compute", "The model answers from retrieved real documents", "Different model"], 1,
              "Retrieval gives the model real source material."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// DIGITAL MARKETER
// =========================================================
const DIGITAL_MARKETER: CareerPath = {
  id: "digital-marketer",
  name: "Digital Marketer",
  tagline: "Grow brands through paid, organic and content channels.",
  emoji: "📈",
  trees: [
    {
      id: "dm-left", title: "Marketing Strategy",
      subtitle: "Choose where to play and why.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "dm-l1", title: "Marketing Funnels", xp: 35, kind: "lesson",
          blurb: "Awareness → consideration → conversion.",
          content: [
            "The funnel: people first hear about you (awareness), then weigh you up (consideration), then buy (conversion), then come back (retention).",
            "Different content for each stage: a TikTok intro at the top, a comparison blog in the middle, a free trial at the bottom.",
          ],
          exercise: "Pick a brand you bought from recently. Map the touchpoints that moved you from 'never heard of them' to 'purchased'.",
          quiz: [
            q("What goes at the TOP of the funnel?",
              ["Discount codes", "Awareness content like short videos", "Onboarding emails"], 1,
              "Top = strangers; you're earning attention, not the sale."),
          ],
        },
        {
          id: "dm-l2", title: "Analytics & KPIs", xp: 40, kind: "lesson",
          blurb: "Measure what matters.",
          content: [
            "Vanity metrics (followers, impressions) feel good but don't always tie to business outcomes. Action metrics (signups, revenue, retention) do.",
            "Pick 1-2 north-star metrics, track everything else as supporting context.",
          ],
          exercise: "Define a north-star metric for a podcast, an e-commerce shop, and a SaaS. They should all be different.",
          quiz: [
            q("Which is most likely a vanity metric?",
              ["Monthly active users", "Total followers", "Average revenue per user"], 1,
              "Followers don't equal income."),
          ],
        },
      ],
    },
    {
      id: "dm-right", title: "Paid & Performance",
      subtitle: "Spend money that returns more.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "dm-r1", title: "Ad Platforms", xp: 40, kind: "lesson",
          blurb: "Meta, Google, TikTok — different beasts.",
          content: [
            "Google Ads catches intent (people searching). Meta/TikTok catches interest (people scrolling). They need different creative.",
            "Always start small: £5-10/day budget, one variable changing at a time, measure for at least 5-7 days before judging.",
          ],
          exercise: "Pick a small business. Which platform fits their customers best, and why?",
          quiz: [
            q("Google Search ads work best for…",
              ["Surprise discovery", "High-intent people actively searching", "Long-form storytelling"], 1,
              "Search captures intent; social captures attention."),
          ],
        },
        {
          id: "dm-r2", title: "Campaign Project", xp: 100, kind: "project",
          blurb: "Plan a real launch campaign.",
          content: [
            "Plan a 14-day launch: pre-launch teasers (organic), launch day push (paid + email), follow-up (retargeting + reviews).",
          ],
          exercise: "Write a 14-day campaign plan for a product you'd actually want. Include channel, message, and metric per day.",
          quiz: [
            q("What's retargeting?",
              ["Buying new traffic", "Showing ads to people who already engaged", "A type of email"], 1,
              "Retargeting catches the warm audience."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// VIDEO EDITOR
// =========================================================
const VIDEO_EDITOR: CareerPath = {
  id: "video-editor",
  name: "Video Editor",
  tagline: "Craft stories that hold attention frame by frame.",
  emoji: "🎞️",
  trees: [
    {
      id: "ve-left", title: "Editing Craft",
      subtitle: "Cuts, pacing, rhythm.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "ve-l1", title: "Cuts & Pacing", xp: 35, kind: "lesson",
          blurb: "When to cut is the whole job.",
          content: [
            "Cut on motion, cut on action, cut to reveal information. Hold shots only as long as new information is arriving.",
            "Fast pacing isn't always better — silence and stillness create emotional weight when used deliberately.",
          ],
          exercise: "Watch a 90-second YouTube intro and count the cuts. What pattern do you see in the first 10 seconds vs the last?",
          quiz: [
            q("When should a shot end?",
              ["After exactly 3 seconds", "When it stops giving new information", "When the audio dips"], 1,
              "Information rate, not the stopwatch."),
          ],
        },
        {
          id: "ve-l2", title: "Sound Design", xp: 40, kind: "lesson",
          blurb: "Audio is half the picture.",
          content: [
            "Audiences forgive bad video; they don't forgive bad audio. Use a real mic, watch the levels (peaks around -6dB), and add subtle music + sound effects to land jokes and transitions.",
          ],
          exercise: "Edit any 30-second clip. Add a music bed at -20dB, raise voice to -6dB peak, and add one whoosh on a transition.",
          quiz: [
            q("What's the bigger problem?",
              ["Slightly blurry video with clean audio", "Sharp video with muffled audio"], 1,
              "Bad audio drives people away faster than bad video."),
          ],
        },
      ],
    },
    {
      id: "ve-right", title: "Story & Delivery",
      subtitle: "Make every second matter.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "ve-r1", title: "Story Structure", xp: 40, kind: "lesson",
          blurb: "Setup → tension → payoff.",
          content: [
            "Every great edit has a question the viewer wants answered. Setup poses it, the middle complicates it, the end answers it (or twists it).",
            "Even a 30-second TikTok benefits from this skeleton.",
          ],
          exercise: "Take a video idea ('I cooked pasta') and turn it into setup/tension/payoff in one sentence each.",
          quiz: [
            q("What keeps a viewer watching?",
              ["High production value", "An open question they want answered", "Loud audio"], 1,
              "Curiosity is the engine."),
          ],
        },
        {
          id: "ve-r2", title: "Portfolio Reel Project", xp: 100, kind: "project",
          blurb: "Edit a 60-second showreel.",
          content: [
            "Your reel is your CV. 60 seconds, your best 6-8 shots, music synced to cuts, your name + contact at the end.",
          ],
          exercise: "Cut a 60-second reel of your best work. Upload it to YouTube unlisted and share the link.",
          quiz: [
            q("Why keep showreels short?",
              ["YouTube limit", "Hiring managers watch 30-60s max", "File size"], 1,
              "Respect their time; show the best fast."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// PRODUCT DESIGNER
// =========================================================
const PRODUCT_DESIGNER: CareerPath = {
  id: "product-designer",
  name: "Product Designer",
  tagline: "Shape products end-to-end, from problem to pixel.",
  emoji: "🧩",
  trees: [
    {
      id: "pd-left", title: "Problem Definition",
      subtitle: "Solve the right thing.",
      hueA: "#9b8cff", hueB: "#5fb6ff",
      nodes: [
        {
          id: "pd-l1", title: "Jobs To Be Done", xp: 40, kind: "lesson",
          blurb: "People 'hire' products for jobs.",
          content: [
            "JTBD: a milkshake is 'hired' for the morning commute (filling, slow to drink, one-handed). The competition isn't other milkshakes — it's bagels and bananas.",
            "Frame features around the user's job, not the company's roadmap.",
          ],
          exercise: "Pick any product. Write the 'job' it's hired for in this format: 'When ___, I want to ___, so that I can ___.'",
          quiz: [
            q("Best framing for a JTBD?",
              ["A persona's age and income", "The situation, motivation, and outcome", "A list of features"], 1,
              "JTBD focuses on situational need."),
          ],
        },
      ],
    },
    {
      id: "pd-right", title: "Prototyping & Delivery",
      subtitle: "Ship and learn fast.",
      hueA: "#ffb37a", hueB: "#ff7ab3",
      nodes: [
        {
          id: "pd-r1", title: "Prototype Fidelity", xp: 40, kind: "lesson",
          blurb: "Right level for the question.",
          content: [
            "Low-fi (paper/Figma boxes): test flow and structure. Hi-fi (visual + interactive): test polish and trust. Don't polish what you might throw away.",
          ],
          exercise: "Sketch a 5-screen flow on paper for any product idea, then ask a friend to talk through it.",
          quiz: [
            q("When should you go hi-fi?",
              ["Always", "Once the flow is validated", "Never"], 1,
              "Validate cheap; polish what survives."),
          ],
        },
        {
          id: "pd-r2", title: "Product Case Study", xp: 100, kind: "project",
          blurb: "Document one project end-to-end.",
          deliverable: { type: "url", prompt: "Share a product design case study link.", examples: ["Notion case study", "Figma prototype link", "PDF case study"] },
          content: [
            "A case study tells the story: problem → users → constraints → process → final design → impact. This is the artefact hiring managers actually read.",
          ],
          exercise: "Write a 1-page case study of any design project you've worked on (or invent one). Include screenshots.",
          quiz: [
            q("What's the single most important section of a case study?",
              ["Tools used", "The problem and the impact", "Hours spent"], 1,
              "Impact = the only thing that proves you can do it again."),
          ],
        },
      ],
    },
  ],
};

// =========================================================
// REGISTRY
// =========================================================
export const CAREER_PATHS: CareerPath[] = [
  CONTENT_CREATOR,
  DATA_ENGINEER,
  CYBER_ANALYST,
  UX_DESIGNER,
  SOFTWARE_DEV,
  AI_ENGINEER,
  DIGITAL_MARKETER,
  VIDEO_EDITOR,
  PRODUCT_DESIGNER,
];

export function getCareer(id?: string): CareerPath {
  return CAREER_PATHS.find((c) => c.id === id) ?? SOFTWARE_DEV;
}

export function allNodes(career: CareerPath): CareerNode[] {
  return [...career.trees[0].nodes, ...career.trees[1].nodes];
}
