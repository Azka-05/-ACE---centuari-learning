import type { UserData } from "@/lib/app-state";

export interface Mentor { id:string; name:string; role:string; company:string; city:string; skills:string[]; tags:string[]; bio:string; linkedin:string; }

export const DYNAMIC_MENTORS: Mentor[] = [
  { id:"aisha", name:"Aisha Rahman", role:"Frontend Developer", company:"BBC", city:"Birmingham", skills:["coding","web development","UX/UI design"], tags:["self-taught","non-london","first-gen-uni"], bio:"Started with freeCodeCamp and community projects before moving into accessible frontend work.", linkedin:"#" },
  { id:"samira", name:"Samira Khan", role:"Product Designer", company:"Monzo", city:"London", skills:["UX/UI design","product design","research"], tags:["career-change","first-gen-uni"], bio:"Designs inclusive banking journeys and mentors young people building their first case study.", linkedin:"#" },
  { id:"ryan", name:"Ryan Mensah", role:"Cyber Analyst", company:"NCC Group", city:"Manchester", skills:["cybersecurity","coding"], tags:["bootcamp-grad","self-taught","non-london"], bio:"Moved into cyber through CTFs, home labs and a bootcamp after working retail.", linkedin:"#" },
  { id:"nabila", name:"Nabila Ahmed", role:"AI Engineer", company:"Faculty", city:"Leeds", skills:["AI","data","coding"], tags:["neurodivergent","first-gen-uni","non-london"], bio:"Builds practical AI tools and supports learners who prefer visual, step-by-step explanations.", linkedin:"#" },
  { id:"ella", name:"Ella Thompson", role:"Digital Marketer", company:"Gymshark", city:"Birmingham", skills:["digital marketing","content creation"], tags:["career-change","non-london"], bio:"Turns social experiments into campaigns and helps beginners understand analytics without jargon.", linkedin:"#" },
  { id:"omar", name:"Omar Farooq", role:"Data Engineer", company:"Sky", city:"London", skills:["data","AI","coding"], tags:["self-taught","first-gen-uni"], bio:"Started by cleaning messy spreadsheets and now builds pipelines that power reporting teams.", linkedin:"#" },
  { id:"grace", name:"Grace Williams", role:"Video Editor", company:"Channel 4", city:"Manchester", skills:["video editing","content creation"], tags:["self-taught","non-london"], bio:"Learnt editing on a phone and now creates short-form reels and broadcast social content.", linkedin:"#" },
  { id:"haroon", name:"Haroon Ali", role:"Software Engineer", company:"Booking.com", city:"Leeds", skills:["coding","web development","game development"], tags:["bootcamp-grad","non-london"], bio:"Mentors beginners through GitHub, small projects and interview confidence.", linkedin:"#" },
];

export function matchedMentors(user: UserData) {
  const city = (user as any).city || "";
  const interests = (user.interests || []).map(i=>i.toLowerCase());
  return DYNAMIC_MENTORS.map(m => {
    const reasons: string[] = [];
    let score = 0;
    if (m.skills.some(s => interests.some(i => s.toLowerCase().includes(i.toLowerCase()) || i.toLowerCase().includes(s.toLowerCase())))) { score += 40; reasons.push("share similar interests"); }
    if (city && m.city.toLowerCase() === city.toLowerCase()) { score += 25; reasons.push(`are both connected to ${m.city}`); }
    if ((user.confidence || "").toLowerCase().includes("new") && (m.tags.includes("self-taught") || m.tags.includes("career-change"))) { score += 20; reasons.push("understand the beginner journey"); }
    if (user.accessibility !== "none" && user.accessibility !== "prefer-not" && m.tags.includes("neurodivergent")) { score += 15; reasons.push("value accessible learning"); }
    if (!reasons.length) reasons.push("can support your next step", "has relevant industry experience");
    return { ...m, score, matchReason: `Matched because you both ${reasons.slice(0,2).join(" and ")}.` };
  }).sort((a,b)=>b.score-a.score).slice(0,4);
}
