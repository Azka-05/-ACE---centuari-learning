import { createServerFn } from "@tanstack/react-start";

interface ChatMessage { role: "user" | "assistant"; content: string }

const SYSTEM = `You are the Centauri Learning helper — a friendly, calm assistant on a youth digital-inclusion platform.
Answer briefly (2-4 sentences max) in plain, warm language. Be encouraging and beginner-friendly.

About Centauri Learning:
- Helps young people in underserved UK communities get into tech.
- Three pillars: Tech Access (donated/refurbished devices + internet), Confidence Builder (CV feedback, mock interviews, beginner pathways), Connections (mentor matching, networking).
- Has an accessibility-first design: dyslexia, ADHD, autism, low-vision, anxiety modes, plus light/dark theme.
- Onboarding: name → interests → confidence → CV upload (required) → accessibility prefs.

If asked something outside this scope, gently steer back to what the platform offers. Never invent prices, statistics, or guarantees.`;

export const askChatbot = createServerFn({ method: "POST" })
  .inputValidator((input: { messages: ChatMessage[] }) => {
    if (!Array.isArray(input?.messages)) throw new Error("messages required");
    const messages = input.messages.slice(-10).map((m) => ({
      role: m.role === "assistant" ? "assistant" as const : "user" as const,
      content: String(m.content ?? "").slice(0, 2000),
    }));
    return { messages };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI is not configured yet.");
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{ role: "system", content: SYSTEM }, ...data.messages],
      }),
    });
    if (res.status === 429) throw new Error("Too many questions right now — try again in a moment.");
    if (res.status === 402) throw new Error("AI credits exhausted. Please add credits in Lovable Cloud.");
    if (!res.ok) throw new Error(`Chat failed (${res.status}).`);
    const json = await res.json() as { choices?: { message?: { content?: string } }[] };
    const reply = json.choices?.[0]?.message?.content?.trim() ?? "Sorry, I couldn't think of an answer just now.";
    return { reply };
  });
