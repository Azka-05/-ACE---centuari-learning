// Demo-safe CV parser stub. In production this can call Supabase Storage + Claude.
export async function parseCvForDemo(fileName: string) {
  const lower = fileName.toLowerCase();
  const skills = ["communication", "teamwork"];
  if (lower.includes("ux") || lower.includes("design")) skills.push("UX/UI design", "research");
  if (lower.includes("code") || lower.includes("dev")) skills.push("coding", "web development");
  if (lower.includes("data")) skills.push("data", "AI");
  return { skills, years_experience: null, education_level: "student", industries: ["technology"], skippedLessons: Math.min(2, skills.length - 2) };
}
