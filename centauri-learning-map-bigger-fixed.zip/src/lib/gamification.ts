export interface Lesson {
  id: string;
  title: string;
  kind: "intro" | "quiz" | "practice" | "challenge" | "chest" | "trophy";
  xp: number;
  blurb: string;
}

export interface Pathway {
  id: string;
  title: string;
  emoji: string;
  description: string;
  lessons: Lesson[];
}

export const PATHWAYS: Pathway[] = [
  {
    id: "frontend",
    title: "Frontend Development",
    emoji: "💻",
    description: "Build your first interfaces with HTML, CSS, and a sprinkle of JavaScript.",
    lessons: [
      { id: "fe-1", kind: "intro", title: "What is the web?", xp: 20, blurb: "The internet, explained in 3 minutes." },
      { id: "fe-2", kind: "practice", title: "Fix a broken button", xp: 30, blurb: "Spot the missing tag." },
      { id: "fe-3", kind: "quiz", title: "HTML quick quiz", xp: 25, blurb: "5 friendly questions." },
      { id: "fe-4", kind: "chest", title: "Reward chest", xp: 60, blurb: "You unlocked a bonus." },
      { id: "fe-5", kind: "practice", title: "Style your first card", xp: 35, blurb: "Padding, colour, radius." },
      { id: "fe-6", kind: "challenge", title: "Build a profile card", xp: 80, blurb: "Put it together." },
      { id: "fe-7", kind: "quiz", title: "CSS confidence check", xp: 25, blurb: "Quick recall." },
      { id: "fe-8", kind: "trophy", title: "Unit trophy", xp: 120, blurb: "Mentor unlock available." },
    ],
  },
  {
    id: "uxui",
    title: "UX / UI Design",
    emoji: "🎨",
    description: "Learn how to design clear, kind, useful interfaces.",
    lessons: [
      { id: "ux-1", kind: "intro", title: "Why design matters", xp: 20, blurb: "Empathy as a tool." },
      { id: "ux-2", kind: "practice", title: "Improve a sign-up form", xp: 30, blurb: "Spot 3 frictions." },
      { id: "ux-3", kind: "quiz", title: "Colour & contrast", xp: 25, blurb: "Accessibility basics." },
      { id: "ux-4", kind: "chest", title: "Reward chest", xp: 60, blurb: "Nice work." },
      { id: "ux-5", kind: "challenge", title: "Sketch a profile screen", xp: 80, blurb: "Low-fi, paper or Figma." },
    ],
  },
  {
    id: "cyber",
    title: "Cybersecurity Fundamentals",
    emoji: "🛡️",
    description: "Spot the scams, secure your accounts, think like a defender.",
    lessons: [
      { id: "cy-1", kind: "intro", title: "Online safety 101", xp: 20, blurb: "Passwords and 2FA." },
      { id: "cy-2", kind: "practice", title: "Spot the phishing email", xp: 35, blurb: "5 emails, 3 are sus." },
      { id: "cy-3", kind: "quiz", title: "Quick threat check", xp: 25, blurb: "Test your instincts." },
      { id: "cy-4", kind: "chest", title: "Reward chest", xp: 60, blurb: "Defender XP." },
    ],
  },
];

export interface DailyQuest {
  id: string;
  title: string;
  goal: number;
  xp: number;
  chest: "wood" | "gold" | "diamond";
}

export const DAILY_QUESTS: DailyQuest[] = [
  { id: "q-lesson", title: "Complete 1 lesson", goal: 1, xp: 40, chest: "wood" },
  { id: "q-quiz", title: "Get 5 in a row on a quiz", goal: 5, xp: 60, chest: "gold" },
  { id: "q-network", title: "Send 1 networking message", goal: 1, xp: 50, chest: "wood" },
  { id: "q-portfolio", title: "Add one note to your portfolio", goal: 1, xp: 70, chest: "diamond" },
];

export function levelFromXp(xp: number) {
  // 200 XP per level, soft curve
  const level = Math.floor(Math.sqrt(xp / 50)) + 1;
  const prev = ((level - 1) ** 2) * 50;
  const next = (level ** 2) * 50;
  const pct = Math.max(0, Math.min(1, (xp - prev) / (next - prev)));
  return { level, prev, next, pct };
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}
