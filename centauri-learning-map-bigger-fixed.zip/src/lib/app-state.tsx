import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type AccessibilityMode =
  | "none"
  | "dyslexia"
  | "adhd"
  | "autism"
  | "visual"
  | "anxiety"
  | "prefer-not";

export type ThemeMode = "light" | "dark";

export interface UserData {
  name: string;
  email: string;
  interests: string[];
  confidence: string;
  devices: string[];
  accessibility: AccessibilityMode;
  cvUploaded: boolean;
  cvName?: string;
  basket: string[];
  dreamCareer?: string;
  // Gamification
  xp: number;
  streak: number;
  lastActive?: string; // ISO date (YYYY-MM-DD)
  completedLessons: string[]; // lesson ids
  questsCompleted: string[]; // quest ids for today
  questsDate?: string; // date the quests apply to
  badges: string[];
  actionHistory: string[]; // one-time XP source keys
  xpToast?: { amount: number; label: string; id: number };
  projects: { id: string; nodeId: string; title: string; careerId?: string; deliverableType: "url" | "file" | "video"; deliverableUrl: string; submittedAt: string }[];
  deviceRequests: { id: string; items: string[]; reason: string; urgency: string; location: string; createdAt: string }[];
  mentorBookings: { id: string; mentorId: string; date: string; createdAt: string }[];
  cvParsed?: { skills: string[]; years_experience: number | null; education_level: string; industries: string[]; skippedLessons?: number };
}

const DEFAULT_USER: UserData = {
  name: "",
  email: "",
  interests: [],
  confidence: "",
  devices: [],
  accessibility: "none",
  cvUploaded: false,
  basket: [],
  xp: 0,
  streak: 0,
  completedLessons: [],
  questsCompleted: [],
  badges: [],
  actionHistory: [],
  projects: [],
  deviceRequests: [],
  mentorBookings: [],
};

interface AppState {
  user: UserData;
  setUser: (u: UserData) => void;
  updateUser: (patch: Partial<UserData>) => void;
  theme: ThemeMode;
  toggleTheme: () => void;
  session: Session | null;
  authReady: boolean;
  signOut: () => Promise<void>;
  hasOnboarded: boolean;
  awardXp: (source: string, amount: number, label?: string) => boolean;
}

const Ctx = createContext<AppState | null>(null);

const userKey = (id: string | undefined) => (id ? `techfinder.user.${id}` : "techfinder.user");

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<UserData>(DEFAULT_USER);
  const [theme, setTheme] = useState<ThemeMode>("dark");
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);

  // Theme bootstrap
  useEffect(() => {
    try {
      const t = localStorage.getItem("techfinder.theme") as ThemeMode | null;
      if (t) setTheme(t);
    } catch {}
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    try { localStorage.setItem("techfinder.theme", theme); } catch {}
  }, [theme]);

  // Auth bootstrap — listener FIRST, then getSession
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthReady(true);
    });
    return () => subscription.unsubscribe();
  }, []);

  // Load per-user profile from localStorage when session changes
  useEffect(() => {
    try {
      const raw = localStorage.getItem(userKey(session?.user.id));
      if (raw) {
        setUserState({ ...DEFAULT_USER, ...JSON.parse(raw) });
      } else if (session?.user) {
        setUserState({ ...DEFAULT_USER, email: session.user.email ?? "" });
      } else {
        setUserState(DEFAULT_USER);
      }
    } catch {}
  }, [session?.user.id]);

  // Persist user + apply a11y class
  useEffect(() => {
    const root = document.documentElement;
    ["a11y-dyslexia", "a11y-adhd", "a11y-autism", "a11y-visual", "a11y-anxiety"].forEach((c) =>
      root.classList.remove(c)
    );
    if (user.accessibility && user.accessibility !== "none" && user.accessibility !== "prefer-not") {
      root.classList.add(`a11y-${user.accessibility}`);
    }
    try { localStorage.setItem(userKey(session?.user.id), JSON.stringify(user)); } catch {}
  }, [user, session?.user.id]);

  const setUser = (u: UserData) => setUserState(u);
  const updateUser = (patch: Partial<UserData>) => setUserState((p) => ({ ...p, ...patch }));
  const awardXp = (source: string, amount: number, label = "XP gained") => {
    let granted = false;
    setUserState((p) => {
      const history = p.actionHistory ?? [];
      if (history.includes(source)) return p;
      granted = true;
      return {
        ...p,
        xp: (p.xp || 0) + amount,
        actionHistory: [...history, source],
        xpToast: { amount, label, id: Date.now() },
      };
    });
    return granted;
  };
  const toggleTheme = () => {
    const swap = () => setTheme((t) => (t === "dark" ? "light" : "dark"));
    // Use the View Transitions API for a smooth cross-fade when available.
    const doc = document as Document & { startViewTransition?: (cb: () => void) => unknown };
    if (typeof doc.startViewTransition === "function") {
      doc.startViewTransition(swap);
    } else {
      swap();
    }
  };
  const signOut = async () => { await supabase.auth.signOut(); };

  const hasOnboarded = !!(user.name && user.interests.length > 0);

  return (
    <Ctx.Provider value={{ user, setUser, updateUser, theme, toggleTheme, session, authReady, signOut, hasOnboarded, awardXp }}>
      {children}
    </Ctx.Provider>
  );
}

export function useApp() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useApp must be inside AppProvider");
  return c;
}
