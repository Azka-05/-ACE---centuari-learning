
# Centauri Learning — Redesign Plan

This is a large scope. I'll ship it in focused phases so you can review and steer between each. Every phase keeps the existing constellation aesthetic — softer, warmer, more accessible — and avoids the "generic AI template" look.

## Phase 1 — Foundation: palette, type, accessibility settings (ship first)

- Retune tokens in `src/styles.css`: desaturate orange/purple ~15%, raise text contrast to WCAG AA on all surfaces, soften glows, larger default radii, calmer shadows.
- Add an **Accessibility panel** (gear icon in Navbar) with persisted settings:
  - Font size (S / M / L / XL) — scales root rem
  - Reduced motion toggle (respects `prefers-reduced-motion`, overrideable)
  - High contrast mode
  - Dyslexia-friendly font (OpenDyslexic via system fallback stack)
  - Theme toggle stays here too
- Global focus-visible ring, min 44px tap targets, keyboard nav audit.
- Store in `app-state` + `localStorage`, apply via `data-*` attributes on `<html>`.

## Phase 2 — Text-to-Speech system

- `useSpeech()` hook wrapping Web Speech API (no API key, works offline, mobile-friendly).
- `<ListenButton text={...} />` component: speaker icon, play/pause/stop, speed slider (0.75x–1.5x), word-level highlight via `boundary` events.
- "Listen instead" prominent CTA on missions/lesson cards.
- Respects reduced-motion and accessibility settings.

## Phase 3 — Home + dashboard warmth pass

- Softer constellation background (fewer, slower particles; lower opacity).
- Replace static welcome with rotating motivational line tied to user's pathway.
- "Today's mission" card: warmer copy, Listen button, momentum meter (renamed from progress).
- Streak + weekly goal chip, subtle XP-to-unlock hint ("3 more missions → mentor session").
- Hover/press microinteractions: gentle lift, no neon flare.

## Phase 4 — Explore "Future Map" polish

- Keep current node tree. Add: soft pulse on unlocked nodes, connecting line draw-in on mount, hover reveals reward chip ("Unlocks: portfolio project").
- Leaderboard stays centered; add community activity strip below ("12 learners working on this pathway today").

## Phase 5 — Onboarding expansion

Add questions after existing ones (all required):
- Device (phone only / shared laptop / own laptop / tablet)
- Barriers (multi-select: poor internet, no mentor, beginner confidence, limited time, shared device)
- Confidence (1–5 slider)
- Weekly time (<2h / 2–5h / 5–10h / 10h+)
- Learning preference (video / reading / hands-on / audio)

Persist to `app-state`. Adapt experience:
- `phoneOnly` → compact mobile layouts, hide wide tables
- `lowConfidence` → encouraging copy variants, more Listen prompts
- `limitedTime` → surface short missions first
- `poorInternet` → "Download for offline" badges on resources

## Phase 6 — Mentorship + Access + Community

- Mentor cards: larger avatars, "Why we matched you" chip (shared interest from onboarding), availability dot, self-taught/first-gen tags. Keep the 3 real LinkedIn profiles.
- Access hub: reframe as "Support matched to you" — cards show suitability tags (coding-ready, design-ready, delivery available, broadband included).
- New `/community` lite section on dashboard: learning squad placeholder, peer activity feed (mocked), mentor office hours next slot.

## Phase 7 — Gamification language + motion

- Global rename: lessons→missions, modules→pathways, progress→momentum.
- XP unlock animation (subtle star bloom, respects reduced-motion).
- "Future expanding" visual: small constellation in profile that grows with momentum.

## Technical notes

- All visual work stays in frontend (`src/styles.css`, components, routes). No schema changes.
- TTS uses browser-native Web Speech API — no ElevenLabs needed unless you want premium voices later (can swap in Phase 2.5).
- Accessibility settings persist via `localStorage` through existing `app-state` context.
- No new dependencies expected except possibly `@radix-ui/react-slider` if not already present.

## What I'll do next

If you approve, I'll ship **Phase 1 + Phase 2 together** (foundation + TTS) since they unlock everything else, then pause for your review before continuing. Reply "go" or tell me to reorder / drop phases.
